
import SwiftUI
import AVFoundation
import FirebaseAuth
import FirebaseFirestore
import UIKit
import CoreVideo
import CoreMedia
import WebRTC

// MARK: - Schema

private enum TaskFields {
    static let collection = "tasks"
    static let name = "name"
    static let type = "type"
    static let deviceID = "deviceID"
    static let startedAt = "startedAt"
    static let endedAt = "endedAt"
    static let endedBy = "endedBy"
    static let hasSamples = "hasSamples"
    static let deviceName = "deviceName"
}

private enum CameraEventFields {
    static let subcollection = "events"
    static let t = "t"
    static let type = "type"
    static let meta = "meta"
}

private enum WebRTCFields {
    static let subcollection = "webrtc"
    static let offerDoc = "offer"
    static let answerDoc = "answer"
    static let callerCandidates = "callerCandidates"
    static let calleeCandidates = "calleeCandidates"
    static let sdp = "sdp"
    static let type = "type"
    static let createdAt = "createdAt"
}

// MARK: - Setup View

struct CameraTaskSetupView: View {
    let functionTitle: String
    @State private var notifyOnMotion: Bool = true

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(functionTitle)
                .font(.largeTitle.bold())

            Text("Live remote camera feed + motion alerts.")
                .foregroundStyle(.secondary)

            Toggle("Notify on Motion", isOn: $notifyOnMotion)
                .tint(.green)

            Spacer()

            NavigationLink {
                CameraTaskLiveView(taskId: nil, notifyOnMotion: notifyOnMotion)
            } label: {
                Text("Start Camera")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.green.opacity(0.85))
                    .foregroundStyle(.black)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
            }
        }
        .padding()
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Live View

struct CameraTaskLiveView: View {
    /// nil = start NEW camera task (broadcaster)
    /// non-nil = open existing task (viewer if another device started it)
    let taskId: String?
    let notifyOnMotion: Bool

    @Environment(\.dismiss) private var dismiss
    @StateObject private var controller = CameraTaskController()

    @State private var statusText: String = "starting…"
    @State private var errorText: String?

    var body: some View {
        VStack(spacing: 12) {

            ZStack(alignment: .topLeading) {
                if controller.mode == .broadcaster {
                    // Local camera preview
                    CameraPreview(session: controller.captureSession)
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                } else {
                    // Remote stream view
                    WebRTCVideoView(renderer: controller.remoteRenderer)
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                }

                VStack(alignment: .leading, spacing: 6) {
                    Text(controller.mode == .broadcaster ? "Camera (Broadcasting)" : "Camera (Viewing)")
                        .font(.headline)
                    Text(statusText)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(10)
                .background(.thinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .padding(10)
            }
            .frame(maxWidth: .infinity)
            .aspectRatio(9/16, contentMode: .fit)

            if let errorText {
                Text(errorText)
                    .foregroundStyle(.red)
                    .font(.footnote)
            }

            HStack(spacing: 10) {

                if controller.mode == .broadcaster {
                    Button {
                        controller.flipCamera()
                    } label: {
                        Label("Flip", systemImage: "camera.rotate")
                    }
                    .buttonStyle(.bordered)
                }

                Spacer()

                Button(role: .destructive) {
                    Task {
                        await controller.stopAndEndTask()
                        dismiss()
                    }
                } label: {
                    Label("Stop", systemImage: "stop.fill")
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .padding()
        .navigationTitle("Live")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            Task {
                do {
                    try await controller.start(existingTaskId: taskId, notifyOnMotion: notifyOnMotion)
                    statusText = controller.mode == .broadcaster ? "broadcasting…" : "connecting…"
                } catch {
                    errorText = error.localizedDescription
                    statusText = "error"
                }
            }
        }
    }
}

// MARK: - Controller

@MainActor
final class CameraTaskController: NSObject, ObservableObject {

    enum Mode { case broadcaster, viewer }

    @Published private(set) var mode: Mode = .broadcaster

    // Capture (broadcaster only)
    let captureSession = AVCaptureSession()
    private let captureQueue = DispatchQueue(label: "camera.capture.queue")
    private var videoOutput: AVCaptureVideoDataOutput?
    private var currentInput: AVCaptureDeviceInput?
    private var currentPosition: AVCaptureDevice.Position = .front

    // Firestore
    private let db = Firestore.firestore()
    private var userUID: String?
    private var localDeviceID: String?
    private var activeTaskId: String?
    private var activeTaskDeviceID: String?

    // WebRTC
    private let rtcFactory: RTCPeerConnectionFactory = {
        RTCInitializeSSL()
        let encoderFactory = RTCDefaultVideoEncoderFactory()
        let decoderFactory = RTCDefaultVideoDecoderFactory()
        return RTCPeerConnectionFactory(encoderFactory: encoderFactory, decoderFactory: decoderFactory)
    }()

    private var peerConnection: RTCPeerConnection?
    private var localVideoTrack: RTCVideoTrack?
    private var localCapturer: RTCCameraVideoCapturer?
    private var signalingListeners: [ListenerRegistration] = []

    // Renderer for remote video
    let remoteRenderer = RTCMTLVideoView()

    // Motion detection (broadcaster only) — no samples stored
    private var notifyOnMotion: Bool = true

    // Frame-diff grid
    private var previousGrid: [UInt8]?
    private var inMotion: Bool = false
    private var lastMotionStartAt: Date = .distantPast
    private var lastNotifyAt: Date = .distantPast
    private var quietSince: Date?

    // Anti-spam tuning
    private let gridSize: Int = 14
    private let motionDiffThreshold: Double = 0.12        // avg abs diff of normalized luma samples
    private let quietDiffThreshold: Double = 0.05         // hysteresis to re-arm
    private let quietRearmSeconds: TimeInterval = 2.0     // must be quiet this long to re-arm
    private let cooldownSeconds: TimeInterval = 30.0      // backstop: never >1 notification per 30s

    // MARK: - Public

    func start(existingTaskId: String?, notifyOnMotion: Bool) async throws {
        self.notifyOnMotion = notifyOnMotion

        guard let uid = Auth.auth().currentUser?.uid else {
            throw NSError(domain: "CameraTask", code: 401, userInfo: [NSLocalizedDescriptionKey: "Not signed in."])
        }
        self.userUID = uid

        let did = UserDefaults.standard.string(forKey: "deviceID") ?? {
            let new = UUID().uuidString
            UserDefaults.standard.set(new, forKey: "deviceID")
            return new
        }()
        self.localDeviceID = did

        if let existingTaskId {
            self.activeTaskId = existingTaskId
            // Determine who owns the task (broadcaster deviceID)
            let taskDoc = try await db.collection("users").document(uid)
                .collection(TaskFields.collection).document(existingTaskId).getDocument()

            guard let data = taskDoc.data(),
                  let ownerDeviceID = data[TaskFields.deviceID] as? String else {
                throw NSError(domain: "CameraTask", code: 404, userInfo: [NSLocalizedDescriptionKey: "Task not found or missing deviceID."])
            }

            self.activeTaskDeviceID = ownerDeviceID
            self.mode = (ownerDeviceID == did) ? .broadcaster : .viewer

            if self.mode == .broadcaster {
                // Continue broadcasting on this device for this taskId
                try await startBroadcasting(uid: uid, taskId: existingTaskId)
            } else {
                // View remote stream
                try await startViewing(uid: uid, taskId: existingTaskId)
            }
        } else {
            // Start NEW camera task on this device
            try await forceEndAllTasks(endedBy: "camera_start")
            let newTaskId = try await createCameraTaskDoc(uid: uid, deviceID: did)
            self.activeTaskId = newTaskId
            self.activeTaskDeviceID = did
            self.mode = .broadcaster
            try await startBroadcasting(uid: uid, taskId: newTaskId)
        }
    }

    func stopAndEndTask() async {
        stopWebRTC()
        stopCaptureSession()

        previousGrid = nil
        inMotion = false
        quietSince = nil

        // End task doc if we are the broadcaster (owner).
        guard let uid = userUID, let tid = activeTaskId else { return }
        if activeTaskDeviceID == localDeviceID {
            await endTaskDoc(uid: uid, taskId: tid, endedBy: "user_stop")
        }

        activeTaskId = nil
        activeTaskDeviceID = nil
    }

    func flipCamera() {
        guard mode == .broadcaster else { return }
        currentPosition = (currentPosition == .front) ? .back : .front
        restartBroadcasterCapture()
    }

    // MARK: - Broadcaster

    private func startBroadcasting(uid: String, taskId: String) async throws {
        try await configureAndStartCaptureSession()

        // WebRTC: create PC, create offer, publish offer + ICE to Firestore, listen for answer
        let pc = makePeerConnection(uid: uid, taskId: taskId, isCaller: true)
        self.peerConnection = pc

        // Create local video track via RTCCameraVideoCapturer
        try startWebRTCLocalCamera(on: pc)

        // Create offer
        let constraints = RTCMediaConstraints(mandatoryConstraints: [
            "OfferToReceiveVideo": "false"
        ], optionalConstraints: [
            "DtlsSrtpKeyAgreement": "true"
        ])

        let offer = try await pc.offer(for: constraints)
        try await pc.setLocalDescription(offer)

        // Write offer
        try await setSignalingDoc(uid: uid, taskId: taskId, doc: WebRTCFields.offerDoc, sdp: offer)

        // Listen for answer
        listenForRemoteDescription(uid: uid, taskId: taskId, doc: WebRTCFields.answerDoc) { [weak self] sdp in
            guard let self else { return }
            Task { @MainActor in
                do {
                    try await self.peerConnection?.setRemoteDescription(sdp)
                } catch {
                    // ignore
                }
            }
        }

        // Listen for callee ICE candidates
        listenForIceCandidates(uid: uid, taskId: taskId, collection: WebRTCFields.calleeCandidates) { [weak self] candidate in
            self?.peerConnection?.add(candidate)
        }
    }

    private func restartBroadcasterCapture() {
        stopCaptureSession()
        Task {
            do {
                try await configureAndStartCaptureSession()
                // Also restart WebRTC capture
                if let pc = peerConnection {
                    // stop old capturer and start new
                    await localCapturer?.stopCapture()
                    try startWebRTCLocalCamera(on: pc)
                }
            } catch {
                // ignore
            }
        }
    }

    // MARK: - Viewer

    private func startViewing(uid: String, taskId: String) async throws {
        // WebRTC: create PC, listen for offer, set remote, create answer, publish answer, exchange ICE
        let pc = makePeerConnection(uid: uid, taskId: taskId, isCaller: false)
        self.peerConnection = pc

        // When remote track arrives, render it
        // handled in peerConnection delegate

        // Listen for offer
        listenForRemoteDescription(uid: uid, taskId: taskId, doc: WebRTCFields.offerDoc) { [weak self] offerSdp in
            guard let self else { return }
            Task { @MainActor in
                do {
                    try await self.peerConnection?.setRemoteDescription(offerSdp)

                    let constraints = RTCMediaConstraints(mandatoryConstraints: [
                        "OfferToReceiveVideo": "true"
                    ], optionalConstraints: [
                        "DtlsSrtpKeyAgreement": "true"
                    ])

                    let answer = try await self.peerConnection?.answer(for: constraints)
                    try await self.peerConnection?.setLocalDescription(answer!)
                    try await self.setSignalingDoc(uid: uid, taskId: taskId, doc: WebRTCFields.answerDoc, sdp: answer!)
                } catch {
                    // ignore
                }
            }
        }

        // Listen for caller ICE candidates
        listenForIceCandidates(uid: uid, taskId: taskId, collection: WebRTCFields.callerCandidates) { [weak self] candidate in
            self?.peerConnection?.add(candidate)
        }
    }

    // MARK: - AVCapture local preview (broadcaster UI) + motion detection input

    private func configureAndStartCaptureSession() async throws {
        let authorized = await requestCameraAccessIfNeeded()
        guard authorized else {
            throw NSError(domain: "CameraTask", code: 403, userInfo: [NSLocalizedDescriptionKey: "Camera access not granted."])
        }

        try await withCheckedThrowingContinuation { cont in
            captureQueue.async {
                do {
                    self.captureSession.beginConfiguration()
                    self.captureSession.sessionPreset = .high

                    self.captureSession.inputs.forEach { self.captureSession.removeInput($0) }
                    self.captureSession.outputs.forEach { self.captureSession.removeOutput($0) }

                    let device = try self.selectDevice(position: self.currentPosition)
                    let input = try AVCaptureDeviceInput(device: device)

                    guard self.captureSession.canAddInput(input) else {
                        throw NSError(domain: "CameraTask", code: 1, userInfo: [NSLocalizedDescriptionKey: "Cannot add camera input."])
                    }
                    self.captureSession.addInput(input)
                    self.currentInput = input

                    let output = AVCaptureVideoDataOutput()
                    output.videoSettings = [
                        kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA
                    ]
                    output.alwaysDiscardsLateVideoFrames = true
                    output.setSampleBufferDelegate(self, queue: DispatchQueue(label: "camera.frames.queue"))

                    guard self.captureSession.canAddOutput(output) else {
                        throw NSError(domain: "CameraTask", code: 2, userInfo: [NSLocalizedDescriptionKey: "Cannot add video output."])
                    }
                    self.captureSession.addOutput(output)
                    self.videoOutput = output

                    if let conn = output.connection(with: .video) {
                        conn.videoOrientation = .portrait
                    }

                    self.captureSession.commitConfiguration()

                    if !self.captureSession.isRunning {
                        self.captureSession.startRunning()
                    }

                    cont.resume()
                } catch {
                    self.captureSession.commitConfiguration()
                    cont.resume(throwing: error)
                }
            }
        }
    }

    private func stopCaptureSession() {
        captureQueue.async {
            if self.captureSession.isRunning {
                self.captureSession.stopRunning()
            }
        }
    }

    private func selectDevice(position: AVCaptureDevice.Position) throws -> AVCaptureDevice {
        if let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: position) {
            return device
        }
        if let fallback = AVCaptureDevice.default(for: .video) {
            return fallback
        }
        throw NSError(domain: "CameraTask", code: 404, userInfo: [NSLocalizedDescriptionKey: "No camera found."])
    }

    private func requestCameraAccessIfNeeded() async -> Bool {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized: return true
        case .notDetermined: return await AVCaptureDevice.requestAccess(for: .video)
        default: return false
        }
    }

    // MARK: - Firestore task docs

    private func createCameraTaskDoc(uid: String, deviceID: String) async throws -> String {
        let ref = db.collection("users").document(uid).collection(TaskFields.collection).document()

        let cachedName = UserDefaults.standard.string(forKey: "local_device_name")
        let fallbackName = UIDevice.current.name
        let deviceName = (cachedName?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false)
            ? cachedName!
            : fallbackName

        let payload: [String: Any] = [
            TaskFields.name: "Camera",
            TaskFields.type: "camera",
            TaskFields.deviceID: deviceID,
            TaskFields.startedAt: Timestamp(date: Date()),
            TaskFields.endedAt: NSNull(),
            TaskFields.deviceName: deviceName,
            TaskFields.hasSamples: false
        ]

        try await ref.setData(payload, merge: true)
        return ref.documentID
    }

    private func endTaskDoc(uid: String, taskId: String, endedBy: String) async {
        let ref = db.collection("users").document(uid).collection(TaskFields.collection).document(taskId)
        do {
            try await ref.setData([
                TaskFields.endedAt: Timestamp(date: Date()),
                TaskFields.endedBy: endedBy,
                TaskFields.hasSamples: false
            ], merge: true)
        } catch { }
    }

    private func forceEndAllTasks(endedBy: String) async throws {
        guard let uid = Auth.auth().currentUser?.uid else {
            throw NSError(domain: "Auth", code: -1, userInfo: [NSLocalizedDescriptionKey: "No user logged in"])
        }

        let tasksRef = db.collection("users").document(uid).collection(TaskFields.collection)
        let now = FieldValue.serverTimestamp()

        func endDocs(_ docs: [QueryDocumentSnapshot]) async throws {
            guard !docs.isEmpty else { return }
            let batch = db.batch()
            for doc in docs {
                batch.updateData([
                    TaskFields.endedAt: now,
                    TaskFields.endedBy: endedBy
                ], forDocument: doc.reference)
            }
            try await batch.commit()
        }

        let snapNull = try await tasksRef.whereField(TaskFields.endedAt, isEqualTo: NSNull()).getDocuments()
        try await endDocs(snapNull.documents)

        let snapRecent = try await tasksRef.order(by: TaskFields.startedAt, descending: true).limit(to: 60).getDocuments()
        let missingEndedAtDocs = snapRecent.documents.filter { !$0.data().keys.contains(TaskFields.endedAt) }
        try await endDocs(missingEndedAtDocs)
    }

    private func logEvent(type: String, meta: [String: Any] = [:]) async {
        guard let uid = userUID, let taskId = activeTaskId else { return }
        let ref = db.collection("users").document(uid)
            .collection(TaskFields.collection).document(taskId)
            .collection(CameraEventFields.subcollection).document()

        do {
            try await ref.setData([
                CameraEventFields.t: Timestamp(date: Date()),
                CameraEventFields.type: type,
                CameraEventFields.meta: meta
            ], merge: true)
        } catch { }
    }

    // MARK: - Motion notify (edge-trigger + re-arm + cooldown)

    private func handleMotion(diff: Double) {
        guard mode == .broadcaster else { return }
        guard notifyOnMotion else { return }

        let now = Date()

        // In-motion detection
        if diff >= motionDiffThreshold {
            quietSince = nil

            if !inMotion {
                inMotion = true
                lastMotionStartAt = now

                // Cooldown backstop
                if now.timeIntervalSince(lastNotifyAt) >= cooldownSeconds {
                    lastNotifyAt = now
                    Task { @MainActor in
                        await self.logEvent(type: "motion_started", meta: ["diff": diff])
                        NotificationService.shared.sendPush(
                            subject: "Motion detected",
                            body: "Camera detected movement.",
                            taskId: self.activeTaskId,
                            eventType: "motion_detected",
                            sourceDeviceID: self.localDeviceID
                        )
                    }
                } else {
                    Task { @MainActor in
                        await self.logEvent(type: "motion_started_suppressed", meta: ["diff": diff])
                    }
                }
            }

            return
        }

        // Quiet / rearm hysteresis
        if diff <= quietDiffThreshold {
            if quietSince == nil { quietSince = now }

            if inMotion, let qs = quietSince, now.timeIntervalSince(qs) >= quietRearmSeconds {
                inMotion = false
                Task { @MainActor in
                    await self.logEvent(type: "motion_ended")
                }
            }
        } else {
            // mid-zone, don't rearm
            quietSince = nil
        }
    }

    // MARK: - WebRTC setup

    private func makePeerConnection(uid: String, taskId: String, isCaller: Bool) -> RTCPeerConnection {
        let config = RTCConfiguration()
        config.sdpSemantics = .unifiedPlan

        // Public STUN. In real-world remote viewing you likely need TURN too.
        config.iceServers = [
            RTCIceServer(urlStrings: ["stun:stun.l.google.com:19302"])
        ]

        let constraints = RTCMediaConstraints(mandatoryConstraints: nil, optionalConstraints: [
            "DtlsSrtpKeyAgreement": "true"
        ])

        let pc = rtcFactory.peerConnection(with: config, constraints: constraints, delegate: self)

        // ICE candidate routing (caller vs callee)
        // handled in delegate when candidates are generated
        return pc!
    }

    private func startWebRTCLocalCamera(on pc: RTCPeerConnection) throws {
        let videoSource = rtcFactory.videoSource()
        let capturer = RTCCameraVideoCapturer(delegate: videoSource)
        self.localCapturer = capturer

        let track = rtcFactory.videoTrack(with: videoSource, trackId: "video0")
        self.localVideoTrack = track

        let streamId = "stream0"
        pc.add(track, streamIds: [streamId])

        // Start capture on selected camera
        guard let camera = RTCCameraVideoCapturer.captureDevices().first(where: { $0.position == currentPosition }) ??
                RTCCameraVideoCapturer.captureDevices().first else {
            throw NSError(domain: "CameraTask", code: 500, userInfo: [NSLocalizedDescriptionKey: "No capture device found for WebRTC."])
        }

        let formats = RTCCameraVideoCapturer.supportedFormats(for: camera)
        guard let format = formats.last else {
            throw NSError(domain: "CameraTask", code: 501, userInfo: [NSLocalizedDescriptionKey: "No supported WebRTC formats."])
        }

        let fpsRanges = format.videoSupportedFrameRateRanges
        let fps = Int((fpsRanges.max(by: { $0.maxFrameRate < $1.maxFrameRate })?.maxFrameRate ?? 24))

        capturer.startCapture(with: camera, format: format, fps: fps)
    }

    private func stopWebRTC() {
        signalingListeners.forEach { $0.remove() }
        signalingListeners.removeAll()

        localCapturer?.stopCapture()
        localCapturer = nil

        peerConnection?.close()
        peerConnection = nil

        localVideoTrack = nil
    }

    // MARK: - Firestore signaling

    private func signalingBase(uid: String, taskId: String) -> CollectionReference {
        db.collection("users").document(uid)
            .collection(TaskFields.collection).document(taskId)
            .collection(WebRTCFields.subcollection)
    }

    private func setSignalingDoc(uid: String, taskId: String, doc: String, sdp: RTCSessionDescription) async throws {
        let ref = signalingBase(uid: uid, taskId: taskId).document(doc)
        try await ref.setData([
            WebRTCFields.type: sdp.type.stringValue,
            WebRTCFields.sdp: sdp.sdp,
            WebRTCFields.createdAt: FieldValue.serverTimestamp()
        ], merge: true)
    }

    private func listenForRemoteDescription(uid: String, taskId: String, doc: String, onSdp: @escaping (RTCSessionDescription) -> Void) {
        let ref = signalingBase(uid: uid, taskId: taskId).document(doc)
        let listener = ref.addSnapshotListener { snap, _ in
            guard let data = snap?.data(),
                  let sdpStr = data[WebRTCFields.sdp] as? String,
                  let typeStr = data[WebRTCFields.type] as? String else { return }

            let type: RTCSdpType = (typeStr == "offer") ? .offer : .answer
            onSdp(RTCSessionDescription(type: type, sdp: sdpStr))
        }
        signalingListeners.append(listener)
    }

    private func candidatesCollection(uid: String, taskId: String, name: String) -> CollectionReference {
        signalingBase(uid: uid, taskId: taskId).document(name).collection("items")
    }

    private func writeIceCandidate(uid: String, taskId: String, collection: String, candidate: RTCIceCandidate) {
        guard let sdp = candidate.sdp as String? else { return }
        let ref = signalingBase(uid: uid, taskId: taskId)
            .document(collection)
            .collection("items")
            .document()

        ref.setData([
            "sdp": sdp,
            "sdpMLineIndex": candidate.sdpMLineIndex,
            "sdpMid": candidate.sdpMid as Any,
            WebRTCFields.createdAt: FieldValue.serverTimestamp()
        ], merge: true)
    }

    private func listenForIceCandidates(uid: String, taskId: String, collection: String, onCandidate: @escaping (RTCIceCandidate) -> Void) {
        let ref = signalingBase(uid: uid, taskId: taskId).document(collection).collection("items")
        let listener = ref.addSnapshotListener { snap, _ in
            guard let changes = snap?.documentChanges else { return }
            for change in changes where change.type == .added {
                let data = change.document.data()
                guard let sdp = data["sdp"] as? String,
                      let sdpMLineIndex = data["sdpMLineIndex"] as? Int else { continue }
                let sdpMid = data["sdpMid"] as? String
                onCandidate(RTCIceCandidate(sdp: sdp, sdpMLineIndex: Int32(sdpMLineIndex), sdpMid: sdpMid))
            }
        }
        signalingListeners.append(listener)
    }
}

// MARK: - AVCapture frame processing (motion detection)

extension CameraTaskController: AVCaptureVideoDataOutputSampleBufferDelegate {

    func captureOutput(_ output: AVCaptureOutput,
                       didOutput sampleBuffer: CMSampleBuffer,
                       from connection: AVCaptureConnection) {

        guard mode == .broadcaster else { return } // viewer doesn't detect
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        CVPixelBufferLockBaseAddress(pixelBuffer, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(pixelBuffer, .readOnly) }

        guard let baseAddress = CVPixelBufferGetBaseAddress(pixelBuffer) else { return }

        let width = CVPixelBufferGetWidth(pixelBuffer)
        let height = CVPixelBufferGetHeight(pixelBuffer)
        let bytesPerRow = CVPixelBufferGetBytesPerRow(pixelBuffer)

        let stepX = max(width / gridSize, 1)
        let stepY = max(height / gridSize, 1)

        var curr: [UInt8] = []
        curr.reserveCapacity(gridSize * gridSize)

        for y in stride(from: 0, to: height, by: stepY) {
            let row = baseAddress.advanced(by: y * bytesPerRow)
            for x in stride(from: 0, to: width, by: stepX) {
                let pixel = row.advanced(by: x * 4) // BGRA
                let b = pixel.load(fromByteOffset: 0, as: UInt8.self)
                let g = pixel.load(fromByteOffset: 1, as: UInt8.self)
                let r = pixel.load(fromByteOffset: 2, as: UInt8.self)

                // Luma approx in 0..255
                let luma = UInt8(min(255, (Int(r) * 54 + Int(g) * 183 + Int(b) * 19) >> 8))
                curr.append(luma)
                if curr.count >= gridSize * gridSize { break }
            }
            if curr.count >= gridSize * gridSize { break }
        }

        guard curr.count > 0 else { return }

        if let prev = previousGrid, prev.count == curr.count {
            var sumDiff: Double = 0
            for i in 0..<curr.count {
                sumDiff += Double(abs(Int(curr[i]) - Int(prev[i]))) / 255.0
            }
            let avgDiff = sumDiff / Double(curr.count)

            // Anti-spam state machine handled on main actor
            Task { @MainActor in
                self.handleMotion(diff: avgDiff)
            }
        }

        previousGrid = curr
    }
}

// MARK: - WebRTC Delegates

extension CameraTaskController: RTCPeerConnectionDelegate {

    func peerConnection(_ peerConnection: RTCPeerConnection, didChange stateChanged: RTCSignalingState) { }
    func peerConnection(_ peerConnection: RTCPeerConnection, didAdd stream: RTCMediaStream) { }
    func peerConnection(_ peerConnection: RTCPeerConnection, didRemove stream: RTCMediaStream) { }
    func peerConnectionShouldNegotiate(_ peerConnection: RTCPeerConnection) { }
    func peerConnection(_ peerConnection: RTCPeerConnection, didChange newState: RTCIceConnectionState) { }
    func peerConnection(_ peerConnection: RTCPeerConnection, didChange newState: RTCIceGatheringState) { }

    func peerConnection(_ peerConnection: RTCPeerConnection, didGenerate candidate: RTCIceCandidate) {
        guard let uid = userUID, let taskId = activeTaskId else { return }
        // Caller writes to callerCandidates, callee writes to calleeCandidates
        let collection = (mode == .broadcaster) ? WebRTCFields.callerCandidates : WebRTCFields.calleeCandidates
        writeIceCandidate(uid: uid, taskId: taskId, collection: collection, candidate: candidate)
    }

    func peerConnection(_ peerConnection: RTCPeerConnection, didRemove candidates: [RTCIceCandidate]) { }

    func peerConnection(_ peerConnection: RTCPeerConnection,
                        didOpen dataChannel: RTCDataChannel) { }

    // Unified Plan: remote track callback
    func peerConnection(_ peerConnection: RTCPeerConnection,
                        didAdd rtpReceiver: RTCRtpReceiver,
                        streams: [RTCMediaStream]) {
        guard mode == .viewer else { return }
        if let track = rtpReceiver.track as? RTCVideoTrack {
            track.add(remoteRenderer)
        }
    }
}

// MARK: - WebRTC Video View

private struct WebRTCVideoView: UIViewRepresentable {
    let renderer: RTCMTLVideoView

    func makeUIView(context: Context) -> RTCMTLVideoView {
        renderer.videoContentMode = .scaleAspectFill
        return renderer
    }

    func updateUIView(_ uiView: RTCMTLVideoView, context: Context) { }
}

// MARK: - Local Camera Preview (broadcaster only)

private struct CameraPreview: UIViewRepresentable {
    let session: AVCaptureSession

    func makeUIView(context: Context) -> PreviewView {
        let v = PreviewView()
        v.videoPreviewLayer.session = session
        v.videoPreviewLayer.videoGravity = .resizeAspectFill
        return v
    }

    func updateUIView(_ uiView: PreviewView, context: Context) {
        uiView.videoPreviewLayer.session = session
    }
}

private final class PreviewView: UIView {
    override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
    var videoPreviewLayer: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
}

// MARK: - Async helpers for WebRTC offer/answer

private extension RTCPeerConnection {
    func offer(for constraints: RTCMediaConstraints) async throws -> RTCSessionDescription {
        try await withCheckedThrowingContinuation { cont in
            self.offer(for: constraints) { sdp, err in
                if let err { cont.resume(throwing: err); return }
                guard let sdp else {
                    cont.resume(throwing: NSError(domain: "WebRTC", code: -1, userInfo: [NSLocalizedDescriptionKey: "Offer was nil"]))
                    return
                }
                cont.resume(returning: sdp)
            }
        }
    }

    func answer(for constraints: RTCMediaConstraints) async throws -> RTCSessionDescription {
        try await withCheckedThrowingContinuation { cont in
            self.answer(for: constraints) { sdp, err in
                if let err { cont.resume(throwing: err); return }
                guard let sdp else {
                    cont.resume(throwing: NSError(domain: "WebRTC", code: -1, userInfo: [NSLocalizedDescriptionKey: "Answer was nil"]))
                    return
                }
                cont.resume(returning: sdp)
            }
        }
    }

 
    func setLocalDescription(_ sdp: RTCSessionDescription) async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            self.setLocalDescription(sdp) { err in
                if let err {
                    cont.resume(throwing: err)
                } else {
                    cont.resume(returning: ())
                }
            }
        }
    }
    
    func setRemoteDescription(_ sdp: RTCSessionDescription) async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            self.setRemoteDescription(sdp) { err in
                if let err {
                    cont.resume(throwing: err)
                } else {
                    cont.resume(returning: ())
                }
            }
        }
    }
}

private extension RTCSdpType {
    var stringValue: String {
        switch self {
        case .offer: return "offer"
        case .answer: return "answer"
        case .prAnswer: return "prAnswer"
        case .rollback: return "rollback"
        @unknown default: return "offer"
        }
    }
}
