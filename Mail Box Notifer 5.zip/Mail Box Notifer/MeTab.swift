
import SwiftUI
import FirebaseAuth
import FirebaseFirestore

/// "Me" / Account screen (production-safe, iOS 15+).
/// - Always returns the user to Sign In by clearing `@AppStorage("userUID")`.
/// - If deletion fails due to "requires recent login", we simply sign out.
struct MeView: View {
    let userUID: String
    private let db = Firestore.firestore()

    @AppStorage("userUID") private var storedUID: String = ""

    @State private var email: String = ""
    @State private var providerSummary: String = ""

    @State private var showSignOutConfirm = false
    @State private var showDeleteConfirm = false

    @State private var isWorking = false
    @State private var statusText: String? = nil   // minimal surface area for errors

    var body: some View {
        AppNavigationContainer {
            List {
                Section(header: Text("Account")) {
                    infoRow(title: "Email", value: email.isEmpty ? "Not available" : email)
                    infoRow(title: "Provider", value: providerSummary.isEmpty ? "Unknown" : providerSummary)
                }

                if let statusText {
                    Section {
                        Text(statusText)
                            .font(.footnote)
                            .foregroundStyle(.red)
                    }
                }

                Section {
                    Button(role: .destructive) {
                        showSignOutConfirm = true
                    } label: {
                        Label("Sign Out", systemImage: "rectangle.portrait.and.arrow.right")
                    }
                    .disabled(isWorking)

                    Button(role: .destructive) {
                        showDeleteConfirm = true
                    } label: {
                        Label(isWorking ? "Working…" : "Delete Account", systemImage: "trash")
                    }
                    .disabled(isWorking)
                }
            }
            .navigationTitle("Me")
            .navigationBarTitleDisplayMode(.large)
            .onAppear(perform: hydrateFromAuth)
            .confirmationDialog(
                "Sign out of this device?",
                isPresented: $showSignOutConfirm,
                titleVisibility: .visible
            ) {
                Button("Sign Out", role: .destructive) {
                    goToSignIn()
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("You’ll need to sign in again to use this app on this device.")
            }
            .confirmationDialog(
                "Delete this account?",
                isPresented: $showDeleteConfirm,
                titleVisibility: .visible
            ) {
                Button("Delete Account", role: .destructive) {
                    statusText = nil
                    deleteAccount()
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("This is permanent. If deletion can’t be completed right now, we’ll sign you out.")
            }
        }
    }

    // MARK: - UI helpers

    private func infoRow(title: String, value: String) -> some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title).font(.subheadline.weight(.semibold))
            Spacer()
            Text(value)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.trailing)
                .lineLimit(2)
        }
    }

    // MARK: - Data hydration

    private func hydrateFromAuth() {
        guard let user = Auth.auth().currentUser else {
            email = ""
            providerSummary = ""
            return
        }

        email = user.email ?? ""
        let providers = user.providerData.map { $0.providerID }
        providerSummary = providers.isEmpty ? "Unknown" : providers.joined(separator: ", ")
    }

    // MARK: - Deletion

    private func deleteAccount() {
        guard let user = Auth.auth().currentUser else {
            goToSignIn()
            return
        }

        isWorking = true

        // 1) Attempt Auth deletion (can fail with requires-recent-login).
        user.delete { error in
            if let error = error as NSError? {
                self.isWorking = false

                // If we can't delete because auth isn't recent enough, we simply sign out (per requirement).
                if error.domain == AuthErrorDomain,
                   error.code == AuthErrorCode.requiresRecentLogin.rawValue {
                    self.goToSignIn()
                    return
                }

                // Any other failure: surface a minimal message, then sign out.
                self.statusText = "Couldn’t delete account right now. Signed you out."
                self.goToSignIn()
                return
            }

            // 2) Best-effort: delete the user root doc (subcollections may remain; rules should prevent access).
            self.db.collection("users").document(self.userUID).delete { _ in
                // Ignore errors here; the account is already gone.
                self.isWorking = false
                self.goToSignIn()
            }
        }
    }

    // MARK: - Sign out / return to Sign In

    private func goToSignIn() {
        // Always return to sign-in by clearing local auth + AppStorage state.
        do { try Auth.auth().signOut() } catch { /* ignore */ }
        storedUID = ""
    }
}
