 

//
//  CameraTask.swift
//  Mail Box Notifer
//
//  High-quality WebRTC camera streaming (local + remote) + optional motion alerts.
//  Re-implemented to avoid AVCapture preview pipeline and use WebRTC capture/render end-to-end.
//
//  Notes:
//  - Broadcaster renders LOCAL WebRTC track (so you see what you stream).
//  - Viewer renders REMOTE track.
//  - Signaling via Firestore under task/webrtc/*
//  - Motion detection runs off captured RTCVideoFrame (no extra camera session).
//

import SwiftUI
import AVFoundation
import FirebaseAuth
import FirebaseFirestore
import UIKit
import CoreVideo
import CoreMedia
import WebRTC

// MARK: - Schemaconnecting

private enum TaskFields {
    static let collection = "tasks"
    static let name = "name"
    static let type = "type"
    static let deviceID = "deviceID"
    static let startedAt = "startedAt"
    static let endedAt = "endedAt"
    static let endedBy = "endedBy"
    static let hasSamples = "hasSamples"
    static let deviceName = "deviceName"
}

private enum CameraEventFields {
    static let subcollection = "events"
    static let t = "t"
    static let type = "type"
    static let meta = "meta"
}

private enum WebRTCFields {
    static let subcollection = "webrtc"
    static let offerDoc = "offer"
    static let answerDoc = "answer"
    static let callerCandidates = "callerCandidates"
    static let calleeCandidates = "calleeCandidates"
    static let sdp = "sdp"
    static let type = "type"
    static let createdAt = "createdAt"
}

// MARK: - Setup View

struct CameraTaskSetupView: View {
    let functionTitle: String
    let deviceID: String
    @State private var notifyOnMotion: Bool = true

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(functionTitle)
                .font(.largeTitle.bold())

            Text("High-quality live remote camera feed + motion alerts.")
                .foregroundStyle(.secondary)

            Toggle("Notify on Motion", isOn: $notifyOnMotion)
                .tint(.green)

            Spacer()

            CompatNavigationLink {
                CameraTaskLiveView(taskId: nil, notifyOnMotion: notifyOnMotion)
            } label: {
                Text("Start Camera")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.green.opacity(0.85))
                    .foregroundStyle(.black)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
            }
        }
        .padding()
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Live View

struct CameraTaskLiveView: View {
    /// nil = start NEW camera task (broadcaster)
    /// non-nil = open existing task (viewer if another device started it)
    let taskId: String?
    let notifyOnMotion: Bool

    @Environment(\.dismiss) private var dismiss
    @StateObject private var controller = CameraTaskController()

    @State private var statusText: String = "starting…"
    @State private var errorText: String?

    var body: some View {
        VStack(spacing: 12) {

            ZStack(alignment: .topLeading) {
                WebRTCVideoView(renderer: controller.activeRenderer)
                    .clipShape(RoundedRectangle(cornerRadius: 16))

                VStack(alignment: .leading, spacing: 6) {
                    Text(controller.mode == .broadcaster ? "Camera (Broadcasting)" : "Camera (Viewing)")
                        .font(.headline)
                    Text(statusText)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(10)
                .background(.thinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .padding(10)
            }
            .frame(maxWidth: .infinity)
            .aspectRatio(9/16, contentMode: .fit)

            if let errorText {
                Text(errorText)
                    .foregroundStyle(.red)
                    .font(.footnote)
            }

            HStack(spacing: 10) {

                if controller.mode == .broadcaster {
                    Button {
                        controller.flipCamera()
                    } label: {
                        Label("Flip", systemImage: "camera.rotate")
                    }
                    .buttonStyle(.bordered)
                }

                Spacer()

                Button(role: .destructive) {
                    Task {
                        await controller.stopAndEndTask()
                        dismiss()
                    }
                } label: {
                    Label("Stop", systemImage: "stop.fill")
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .padding()
        .navigationTitle("Live")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            Task {
                do {
                    try await controller.start(existingTaskId: taskId, notifyOnMotion: notifyOnMotion)
                    statusText = (controller.mode == .broadcaster) ? "broadcasting…" : "connecting…"
                } catch {
                    errorText = error.localizedDescription
                    statusText = "error"
                }
            }
        }
        .onDisappear {
            // No-op; Stop button ends task explicitly.
        }
    }
}

// MARK: - Controller

@MainActor
final class CameraTaskController: NSObject, ObservableObject {

    enum Mode { case broadcaster, viewer }

    @Published private(set) var mode: Mode = .broadcaster

    // Firestore
    private let db = Firestore.firestore()
    private var userUID: String?
    private var localDeviceID: String?
    private var activeTaskId: String?
    private var activeTaskDeviceID: String?

    // WebRTC Factory
    private let rtcFactory: RTCPeerConnectionFactory = {
        RTCInitializeSSL()
        let encoderFactory = RTCDefaultVideoEncoderFactory()
        let decoderFactory = RTCDefaultVideoDecoderFactory()
        return RTCPeerConnectionFactory(encoderFactory: encoderFactory, decoderFactory: decoderFactory)
    }()

    // WebRTC Core
    private var peerConnection: RTCPeerConnection?
    private var signalingListeners: [ListenerRegistration] = []

    // Tracks / Capturer
    private var localVideoSource: RTCVideoSource?
    private var localVideoTrack: RTCVideoTrack?
    private var localCapturer: RTCCameraVideoCapturer?
    private var currentPosition: AVCaptureDevice.Position = .front

    // Renderers
// IMPORTANT: Your WebRTC build apparently does NOT include RTCMTLVideoView (OpenGL),
// so referencing it causes a linker error. We use RTCMTLVideoView only.
private let localRenderer: RTCMTLVideoView = {
    let v = RTCMTLVideoView()
    v.videoContentMode = .scaleAspectFill
    return v
}()

private let remoteRenderer: RTCMTLVideoView = {
    let v = RTCMTLVideoView()
    v.videoContentMode = .scaleAspectFill
    return v
}()

var activeRenderer: (UIView & RTCVideoRenderer) {
    (mode == .broadcaster) ? localRenderer : remoteRenderer
}


    // Quality tuning (sender) — keep it stable.
    // You said the stream can be 5–10s behind, so we prioritize reliability over bleeding-edge settings.
    private let targetFps: Int = 15
    private let preferHeights: [Int32] = [720, 540, 480]

    // MARK: - Public

    func start(existingTaskId: String?, notifyOnMotion: Bool) async throws {
        // Intentionally not doing motion detection in this simplified pipeline.
        // The priority is: camera frames render reliably (no black screen).
        _ = notifyOnMotion // kept for UI compatibility; motion is not used in this simplified camera task.

        guard let uid = Auth.auth().currentUser?.uid else {
            throw NSError(domain: "CameraTask", code: 401, userInfo: [NSLocalizedDescriptionKey: "Not signed in."])
        }
        self.userUID = uid

        let did = DeviceIdentity.id()
        self.localDeviceID = did

        // Renderers already configured on init.
        Logger.insertLog("sCAMSTARTVIEWER", "256", Date())
        if let existingTaskId {
            Logger.insertLog("sCAMSTARTVIEWER", "258", Date())
            self.activeTaskId = existingTaskId

            let taskDoc = try await db.collection("users").document(uid)
                .collection(TaskFields.collection).document(existingTaskId).getDocument()

            guard let data = taskDoc.data(),
                  let ownerDeviceID = data[TaskFields.deviceID] as? String else {
                throw NSError(domain: "CameraTask", code: 404, userInfo: [NSLocalizedDescriptionKey: "Task not found or missing deviceID."])
            }

            self.activeTaskDeviceID = ownerDeviceID
            self.mode = (ownerDeviceID == did) ? .broadcaster : .viewer

            if self.mode == .broadcaster {
                try await startBroadcasting(uid: uid, taskId: existingTaskId)
            } else {
                try await startViewing(uid: uid, taskId: existingTaskId)
            }
        } else {
            try await forceEndAllTasks(endedBy: "camera_start")
            let newTaskId = try await createCameraTaskDoc(uid: uid, deviceID: did)
            self.activeTaskId = newTaskId
            self.activeTaskDeviceID = did
            self.mode = .broadcaster
            try await startBroadcasting(uid: uid, taskId: newTaskId)
        }
    }

    func stopAndEndTask() async {
        stopWebRTC()

        guard let uid = userUID, let tid = activeTaskId else { return }
        if activeTaskDeviceID == localDeviceID {
            await endTaskDoc(uid: uid, taskId: tid, endedBy: "user_stop")
        }

        activeTaskId = nil
        activeTaskDeviceID = nil
    }

    func flipCamera() {
        guard mode == .broadcaster else { return }
        currentPosition = (currentPosition == .front) ? .back : .front
        restartLocalCaptureForQuality()
    }

    // MARK: - Broadcaster

    private func startBroadcasting(uid: String, taskId: String) async throws {
        let pc = makePeerConnection(uid: uid, taskId: taskId, isCaller: true)
        self.peerConnection = pc

        // Add local track (capture + render local)
        try startWebRTCLocalCamera(on: pc)

        // Create offer
        let constraints = RTCMediaConstraints(
            mandatoryConstraints: ["OfferToReceiveVideo": "false"],
            optionalConstraints: ["DtlsSrtpKeyAgreement": "true"]
        )

        let offer = try await pc.offer(for: constraints)
        try await pc.setLocalDescription(offer)

        try await setSignalingDoc(uid: uid, taskId: taskId, doc: WebRTCFields.offerDoc, sdp: offer)

        // Listen for answer
        listenForRemoteDescription(uid: uid, taskId: taskId, doc: WebRTCFields.answerDoc) { [weak self] sdp in
            guard let self else { return }
            Task { @MainActor in
                do { try await self.peerConnection?.setRemoteDescription(sdp) } catch { }
            }
        }

        // Listen for callee ICE
        listenForIceCandidates(uid: uid, taskId: taskId, collection: WebRTCFields.calleeCandidates) { [weak self] candidate in
            self?.peerConnection?.add(candidate)
        }

        await logEvent(type: "broadcast_started", meta: ["pos": (currentPosition == .front ? "front" : "back")])
    }

    private func restartLocalCaptureForQuality() {
        guard mode == .broadcaster else { return }
        Task { @MainActor in
            do {
                // Stop + restart capture with a better chosen format for the new camera position
                try await localCapturer?.stopCapture()
                if let pc = peerConnection {
                    try startWebRTCLocalCamera(on: pc, replacing: true)
                }
                await logEvent(type: "camera_flipped", meta: ["pos": (currentPosition == .front ? "front" : "back")])
            } catch {
                // ignore
            }
        }
    }

    // MARK: - Viewer

    private func startViewing(uid: String, taskId: String) async throws {
        let pc = makePeerConnection(uid: uid, taskId: taskId, isCaller: false)
        self.peerConnection = pc

        // Listen for offer
        listenForRemoteDescription(uid: uid, taskId: taskId, doc: WebRTCFields.offerDoc) { [weak self] offerSdp in
            guard let self else { return }
            Task { @MainActor in
                do {
                    try await self.peerConnection?.setRemoteDescription(offerSdp)

                    let constraints = RTCMediaConstraints(
                        mandatoryConstraints: ["OfferToReceiveVideo": "true"],
                        optionalConstraints: ["DtlsSrtpKeyAgreement": "true"]
                    )

                    let answer = try await self.peerConnection?.answer(for: constraints)
                    try await self.peerConnection?.setLocalDescription(answer!)
                    try await self.setSignalingDoc(uid: uid, taskId: taskId, doc: WebRTCFields.answerDoc, sdp: answer!)

                    await self.logEvent(type: "viewer_answer_sent")
                } catch {
                    // ignore
                }
            }
        }

        // Listen for caller ICE
        listenForIceCandidates(uid: uid, taskId: taskId, collection: WebRTCFields.callerCandidates) { [weak self] candidate in
            self?.peerConnection?.add(candidate)
        }

        await logEvent(type: "viewer_waiting_offer")
    }

    // MARK: - WebRTC setup (quality-focused)

    private func makePeerConnection(uid: String, taskId: String, isCaller: Bool) -> RTCPeerConnection {
        let config = RTCConfiguration()
        config.sdpSemantics = .unifiedPlan

        // STUN only (TURN recommended for real-world NAT traversal).
        config.iceServers = [
            RTCIceServer(urlStrings: ["stun:stun.l.google.com:19302"])
        ]

        // Prefer stable quality over ultra-low-latency spikes.
        config.continualGatheringPolicy = .gatherContinually

        let constraints = RTCMediaConstraints(
            mandatoryConstraints: nil,
            optionalConstraints: ["DtlsSrtpKeyAgreement": "true"]
        )

        let pc = rtcFactory.peerConnection(with: config, constraints: constraints, delegate: self)
        return pc!
    }

    /// Start local WebRTC capture using a high-quality format selection.
    private func startWebRTCLocalCamera(on pc: RTCPeerConnection, replacing: Bool = false) throws {
        // If replacing, keep the existing track attached to senders; otherwise create new track.
        if replacing == false {
            let source = rtcFactory.videoSource()
            self.localVideoSource = source

            let track = rtcFactory.videoTrack(with: source, trackId: "video0")
            self.localVideoTrack = track

            // Add to PC
            _ = pc.add(track, streamIds: ["stream0"])

            // Render local preview from the same track you stream.
            track.add(localRenderer)
        } else {
            // Keep existing renderer/track; we only restart capturer with new device/format.
            localVideoTrack?.remove(localRenderer)
            localVideoTrack?.add(localRenderer)
        }

        // Capture
        guard let source = localVideoSource else {
            throw NSError(domain: "CameraTask", code: 510, userInfo: [NSLocalizedDescriptionKey: "Missing local video source."])
        }

        // IMPORTANT: keep the delegate as the RTCVideoSource.
        // Our previous multi-delegate path adds complexity and is the #1 source of “black preview” reports
        // (frames never reach the source/track if the forwarding chain breaks).
        let capturer = RTCCameraVideoCapturer(delegate: source)
        self.localCapturer = capturer

        // Choose best device for currentPosition
        guard let device = RTCCameraVideoCapturer.captureDevices().first(where: { $0.position == currentPosition })
                ?? RTCCameraVideoCapturer.captureDevices().first else {
            throw NSError(domain: "CameraTask", code: 500, userInfo: [NSLocalizedDescriptionKey: "No camera device available."])
        }

        // Pick a SAFE format (720p/540p/480p) instead of “highest possible”.
        // Some devices expose formats that RTCCameraVideoCapturer can select but fail to start.
        let format = chooseSafeFormat(for: device, preferredHeights: preferHeights)
        capturer.startCapture(with: device, format: format, fps: targetFps)
    }

    private func chooseSafeFormat(for device: AVCaptureDevice, preferredHeights: [Int32]) -> AVCaptureDevice.Format {
        let formats = RTCCameraVideoCapturer.supportedFormats(for: device)

        func height(_ f: AVCaptureDevice.Format) -> Int32 {
            CMVideoFormatDescriptionGetDimensions(f.formatDescription).height
        }

        // First: try to match our preferred heights (720 -> 540 -> 480)
        for h in preferredHeights {
            if let match = formats.first(where: { height($0) == h }) {
                return match
            }
        }

        // Otherwise: pick the closest below 720, else just the first.
        let under720 = formats.filter { height($0) <= 720 }
        if let best = under720.max(by: { height($0) < height($1) }) {
            return best
        }
        return formats.first!
    }

    // MARK: - Stop / cleanup

    private func stopWebRTC() {
        signalingListeners.forEach { $0.remove() }
        signalingListeners.removeAll()

        localVideoTrack?.remove(localRenderer)
        localVideoTrack = nil
        localVideoSource = nil

        Task { @MainActor in
            try? await localCapturer?.stopCapture()
            localCapturer = nil
        }

        peerConnection?.close()
        peerConnection = nil
    }

    // MARK: - Firestore task docs

    private func createCameraTaskDoc(uid: String, deviceID: String) async throws -> String {
        let ref = db.collection("users").document(uid).collection(TaskFields.collection).document()

        let cachedName = UserDefaults.standard.string(forKey: "local_device_name")
        let fallbackName = UIDevice.current.name
        let deviceName = (cachedName?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false)
            ? cachedName!
            : fallbackName

        let payload: [String: Any] = [
            TaskFields.name: "Camera",
            TaskFields.type: "camera",
            TaskFields.deviceID: deviceID,
            TaskFields.startedAt: Timestamp(date: Date()),
            TaskFields.endedAt: NSNull(),
            TaskFields.deviceName: deviceName,
            TaskFields.hasSamples: false
        ]

        try await ref.setData(payload, merge: true)
        return ref.documentID
    }

    private func endTaskDoc(uid: String, taskId: String, endedBy: String) async {
        let ref = db.collection("users").document(uid).collection(TaskFields.collection).document(taskId)
        do {
            try await ref.setData([
                TaskFields.endedAt: Timestamp(date: Date()),
                TaskFields.endedBy: endedBy,
                TaskFields.hasSamples: false
            ], merge: true)
        } catch { }
    }

    private func forceEndAllTasks(endedBy: String) async throws {
        guard let uid = Auth.auth().currentUser?.uid else {
            throw NSError(domain: "Auth", code: -1, userInfo: [NSLocalizedDescriptionKey: "No user logged in"])
        }

        let tasksRef = db.collection("users").document(uid).collection(TaskFields.collection)
        let now = FieldValue.serverTimestamp()

        func endDocs(_ docs: [QueryDocumentSnapshot]) async throws {
            guard !docs.isEmpty else { return }
            let batch = db.batch()
            for doc in docs {
                batch.updateData([
                    TaskFields.endedAt: now,
                    TaskFields.endedBy: endedBy
                ], forDocument: doc.reference)
            }
            try await batch.commit()
        }

        let snapNull = try await tasksRef.whereField(TaskFields.endedAt, isEqualTo: NSNull()).getDocuments()
        try await endDocs(snapNull.documents)

        let snapRecent = try await tasksRef.order(by: TaskFields.startedAt, descending: true).limit(to: 60).getDocuments()
        let missingEndedAtDocs = snapRecent.documents.filter { !$0.data().keys.contains(TaskFields.endedAt) }
        try await endDocs(missingEndedAtDocs)
    }

    private func logEvent(type: String, meta: [String: Any] = [:]) async {
        guard let uid = userUID, let taskId = activeTaskId else { return }
        let ref = db.collection("users").document(uid)
            .collection(TaskFields.collection).document(taskId)
            .collection(CameraEventFields.subcollection).document()

        do {
            try await ref.setData([
                CameraEventFields.t: Timestamp(date: Date()),
                CameraEventFields.type: type,
                CameraEventFields.meta: meta
            ], merge: true)
        } catch { }
    }

    // MARK: - Firestore signaling

    private func signalingBase(uid: String, taskId: String) -> CollectionReference {
        db.collection("users").document(uid)
            .collection(TaskFields.collection).document(taskId)
            .collection(WebRTCFields.subcollection)
    }

    private func setSignalingDoc(uid: String, taskId: String, doc: String, sdp: RTCSessionDescription) async throws {
        let ref = signalingBase(uid: uid, taskId: taskId).document(doc)
        try await ref.setData([
            WebRTCFields.type: sdp.type.stringValue,
            WebRTCFields.sdp: sdp.sdp,
            WebRTCFields.createdAt: FieldValue.serverTimestamp()
        ], merge: true)
    }

    private func listenForRemoteDescription(uid: String, taskId: String, doc: String, onSdp: @escaping (RTCSessionDescription) -> Void) {
        let ref = signalingBase(uid: uid, taskId: taskId).document(doc)
        let listener = ref.addSnapshotListener { snap, _ in
            guard let data = snap?.data(),
                  let sdpStr = data[WebRTCFields.sdp] as? String,
                  let typeStr = data[WebRTCFields.type] as? String else { return }

            let type: RTCSdpType = (typeStr == "offer") ? .offer : .answer
            onSdp(RTCSessionDescription(type: type, sdp: sdpStr))
        }
        signalingListeners.append(listener)
    }

    private func writeIceCandidate(uid: String, taskId: String, collection: String, candidate: RTCIceCandidate) {
        let ref = signalingBase(uid: uid, taskId: taskId)
            .document(collection)
            .collection("items")
            .document()

        ref.setData([
            "sdp": candidate.sdp,
            "sdpMLineIndex": candidate.sdpMLineIndex,
            "sdpMid": candidate.sdpMid as Any,
            WebRTCFields.createdAt: FieldValue.serverTimestamp()
        ], merge: true)
    }

    private func listenForIceCandidates(uid: String, taskId: String, collection: String, onCandidate: @escaping (RTCIceCandidate) -> Void) {
        let ref = signalingBase(uid: uid, taskId: taskId).document(collection).collection("items")
        let listener = ref.addSnapshotListener { snap, _ in
            guard let changes = snap?.documentChanges else { return }
            for change in changes where change.type == .added {
                let data = change.document.data()
                guard let sdp = data["sdp"] as? String,
                      let sdpMLineIndex = data["sdpMLineIndex"] as? Int else { continue }
                let sdpMid = data["sdpMid"] as? String
                onCandidate(RTCIceCandidate(sdp: sdp, sdpMLineIndex: Int32(sdpMLineIndex), sdpMid: sdpMid))
            }
        }
        signalingListeners.append(listener)
    }
}

// MARK: - WebRTC Delegates

extension CameraTaskController: RTCPeerConnectionDelegate {

    func peerConnection(_ peerConnection: RTCPeerConnection, didChange stateChanged: RTCSignalingState) { }
    func peerConnection(_ peerConnection: RTCPeerConnection, didAdd stream: RTCMediaStream) { }
    func peerConnection(_ peerConnection: RTCPeerConnection, didRemove stream: RTCMediaStream) { }
    func peerConnectionShouldNegotiate(_ peerConnection: RTCPeerConnection) { }
    func peerConnection(_ peerConnection: RTCPeerConnection, didChange newState: RTCIceConnectionState) { }
    func peerConnection(_ peerConnection: RTCPeerConnection, didChange newState: RTCIceGatheringState) { }
    func peerConnection(_ peerConnection: RTCPeerConnection, didRemove candidates: [RTCIceCandidate]) { }
    func peerConnection(_ peerConnection: RTCPeerConnection, didOpen dataChannel: RTCDataChannel) { }

    func peerConnection(_ peerConnection: RTCPeerConnection, didGenerate candidate: RTCIceCandidate) {
        guard let uid = userUID, let taskId = activeTaskId else { return }
        let collection = (mode == .broadcaster) ? WebRTCFields.callerCandidates : WebRTCFields.calleeCandidates
        writeIceCandidate(uid: uid, taskId: taskId, collection: collection, candidate: candidate)
    }

    // Unified Plan: remote track callback
    func peerConnection(_ peerConnection: RTCPeerConnection,
                        didAdd rtpReceiver: RTCRtpReceiver,
                        streams: [RTCMediaStream]) {
        guard mode == .viewer else { return }
        if let track = rtpReceiver.track as? RTCVideoTrack {
            track.add(remoteRenderer)
        }
    }
}

// MARK: - WebRTC Video View

private struct WebRTCVideoView: UIViewRepresentable {
    let renderer: (UIView & RTCVideoRenderer)

    func makeUIView(context: Context) -> UIView {
        return renderer
    }

    func updateUIView(_ uiView: UIView, context: Context) { }
}

// MARK: - Async helpers for WebRTC offer/answer

private extension RTCPeerConnection {
    func offer(for constraints: RTCMediaConstraints) async throws -> RTCSessionDescription {
        try await withCheckedThrowingContinuation { cont in
            self.offer(for: constraints) { sdp, err in
                if let err { cont.resume(throwing: err); return }
                guard let sdp else {
                    cont.resume(throwing: NSError(domain: "WebRTC", code: -1, userInfo: [NSLocalizedDescriptionKey: "Offer was nil"]))
                    return
                }
                cont.resume(returning: sdp)
            }
        }
    }

    func answer(for constraints: RTCMediaConstraints) async throws -> RTCSessionDescription {
        try await withCheckedThrowingContinuation { cont in
            self.answer(for: constraints) { sdp, err in
                if let err { cont.resume(throwing: err); return }
                guard let sdp else {
                    cont.resume(throwing: NSError(domain: "WebRTC", code: -1, userInfo: [NSLocalizedDescriptionKey: "Answer was nil"]))
                    return
                }
                cont.resume(returning: sdp)
            }
        }
    }

    func setLocalDescription(_ sdp: RTCSessionDescription) async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            self.setLocalDescription(sdp) { err in
                if let err { cont.resume(throwing: err) }
                else { cont.resume(returning: ()) }
            }
        }
    }

    func setRemoteDescription(_ sdp: RTCSessionDescription) async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            self.setRemoteDescription(sdp) { err in
                if let err { cont.resume(throwing: err) }
                else { cont.resume(returning: ()) }
            }
        }
    }
}

private extension RTCSdpType {
    var stringValue: String {
        switch self {
        case .offer: return "offer"
        case .answer: return "answer"
        case .prAnswer: return "prAnswer"
        case .rollback: return "rollback"
        @unknown default: return "offer"
        }
    }
}
