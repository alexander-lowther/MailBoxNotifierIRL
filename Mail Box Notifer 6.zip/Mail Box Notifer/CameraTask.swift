 
//
//  CameraTask.swift
//  Mail Box Notifer
//
//  WebRTC camera streaming (local + remote) + optional motion alerts.
//  - Broadcaster streams + renders LOCAL track.
//  - Viewer renders REMOTE track.
//  - Signaling via Firestore under /users/{uid}/tasks/{taskId}/webrtc/*
//  - Motion detection runs on broadcaster only (simple + production-safe throttling).
//
//  Notes:
//  - This intentionally keeps the architecture simple (no extra server-side dedupe layer).
//

import SwiftUI
import AVFoundation
import FirebaseAuth
import FirebaseFirestore
import UIKit
import CoreMedia
import WebRTC

// MARK: - Schema

private enum TaskFields {
    static let collection = "tasks"
    static let name = "name"
    static let type = "type"
    static let deviceID = "deviceID"
    static let startedAt = "startedAt"
    static let endedAt = "endedAt"
    static let endedBy = "endedBy"
    static let hasSamples = "hasSamples"
    static let deviceName = "deviceName"
}

private enum CameraEventFields {
    static let subcollection = "events"
    static let t = "t"
    static let type = "type"
    static let meta = "meta"
}

private enum WebRTCFields {
    static let subcollection = "webrtc"
    static let offerDoc = "offer"
    static let answerDoc = "answer"
    static let callerCandidates = "callerCandidates"
    static let calleeCandidates = "calleeCandidates"
    static let sdp = "sdp"
    static let type = "type"
    static let createdAt = "createdAt"
}

// MARK: - Setup View

struct CameraTaskSetupView: View {
    let functionTitle: String
    let deviceID: String
    @State private var notifyOnMotion: Bool = true

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(functionTitle)
                .font(.largeTitle.bold())

            Text("High-quality remote camera feed + optional motion alerts.")
                .foregroundStyle(.secondary)

            Toggle("Notify on Motion", isOn: $notifyOnMotion)
                .tint(.green)

            Spacer()

            CompatNavigationLink {
                // nil => start NEW camera task (broadcaster)
                CameraTaskLiveView(taskId: nil, notifyOnMotion: notifyOnMotion)
            } label: {
                Text("Start Camera")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.green.opacity(0.85))
                    .foregroundStyle(.black)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
            }
        }
        .padding()
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Live View

struct CameraTaskLiveView: View {
    /// nil = start NEW camera task (broadcaster)
    /// non-nil = open existing task (viewer if another device started it)
    let taskId: String?
    let notifyOnMotion: Bool

    @Environment(\.dismiss) private var dismiss
    @StateObject private var controller = CameraTaskController()

    var body: some View {
        VStack(spacing: 12) {
            ZStack(alignment: .topLeading) {
              
                WebRTCVideoView(renderer: controller.activeRenderer)
                    .id(controller.mode == .broadcaster ? "b" : "v")  // ✅ recreate on mode flip
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                
                VStack(alignment: .leading, spacing: 6) {
                    Text(controller.mode == .broadcaster ? "Camera (Broadcasting)" : "Camera (Viewing)")
                        .font(.headline)
                    Text(controller.statusText)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(10)
                .background(.thinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .padding(10)
            }
            .frame(maxWidth: .infinity)
            .aspectRatio(9/16, contentMode: .fit)

            if let err = controller.errorText {
                Text(err)
                    .foregroundStyle(.red)
                    .font(.footnote)
            }

            HStack(spacing: 10) {
                if controller.mode == .broadcaster {
                    Button {
                        controller.flipCamera()
                    } label: {
                        Label("Flip", systemImage: "camera.rotate")
                    }
                    .buttonStyle(.bordered)
                }

                Spacer()

                Button(role: .destructive) {
                    Task {
                        await controller.stopAndEndTask()
                        dismiss()
                    }
                } label: {
                    Label("Stop", systemImage: "stop.fill")
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .padding()
        .navigationTitle("Live")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            Task {
                await controller.start(existingTaskId: taskId, notifyOnMotion: notifyOnMotion)
            }
        }
    }
}

// MARK: - Controller

final class CameraTaskController: NSObject, ObservableObject {

    enum Mode { case broadcaster, viewer }

    @Published private(set) var mode: Mode = .broadcaster
    @Published private(set) var statusText: String = "starting…"
    @Published private(set) var errorText: String?

    var modeKey: String { (mode == .broadcaster) ? "b" : "v" }

    // Firestore
    private let db = Firestore.firestore()
    private var userUID: String?
    private var localDeviceID: String?
    private var activeTaskId: String?
    private var activeTaskDeviceID: String?

    // WebRTC Factory
    private let rtcFactory: RTCPeerConnectionFactory = {
        RTCInitializeSSL()
        let encoderFactory = RTCDefaultVideoEncoderFactory()
        let decoderFactory = RTCDefaultVideoDecoderFactory()
        return RTCPeerConnectionFactory(encoderFactory: encoderFactory, decoderFactory: decoderFactory)
    }()

    // WebRTC Core
    private var peerConnection: RTCPeerConnection?
    private var signalingListeners: [ListenerRegistration] = []

    // Tracks / Capturer
    private var localVideoSource: RTCVideoSource?
    private var localVideoTrack: RTCVideoTrack?
    private var localCapturer: RTCCameraVideoCapturer?
    private var forwarder: VideoFrameForwarder?
    private var currentPosition: AVCaptureDevice.Position = .front

    // Renderers
    private let localRenderer: RTCMTLVideoView = {
        let v = RTCMTLVideoView()
        v.videoContentMode = .scaleAspectFill
        return v
    }()

    private let remoteRenderer: RTCMTLVideoView = {
        let v = RTCMTLVideoView()
        v.videoContentMode = .scaleAspectFill
        return v
    }()

    var activeRenderer: (UIView & RTCVideoRenderer) {
        (mode == .broadcaster) ? localRenderer : remoteRenderer
    }

    // Quality tuning
    private let targetFps: Int = 15
    private let preferHeights: [Int32] = [720, 540, 480]

    // Motion
    private var motionDetector: MotionDetector?
    private var notifyOnMotionEnabled: Bool = false

    // MARK: - Public

    func start(existingTaskId: String?, notifyOnMotion: Bool) async {
        errorText = nil
        statusText = "starting…"

        guard let uid = Auth.auth().currentUser?.uid else {
            errorText = "Not signed in."
            statusText = "error"
            return
        }
        userUID = uid

        let did = DeviceIdentity.id()
        localDeviceID = did

        do {
            if let existingTaskId {
                activeTaskId = existingTaskId

                let taskDoc = try await db.collection("users").document(uid)
                    .collection(TaskFields.collection).document(existingTaskId).getDocument()

                guard let data = taskDoc.data(),
                      let ownerDeviceID = data[TaskFields.deviceID] as? String else {
                    throw NSError(domain: "CameraTask", code: 404, userInfo: [NSLocalizedDescriptionKey: "Task not found or missing deviceID."])
                }

                activeTaskDeviceID = ownerDeviceID
                mode = (ownerDeviceID == did) ? .broadcaster : .viewer

                if mode == .broadcaster {
                    notifyOnMotionEnabled = notifyOnMotion
                    try await startBroadcasting(uid: uid, taskId: existingTaskId)
                } else {
                    notifyOnMotionEnabled = false // viewer never runs motion
                    try await startViewing(uid: uid, taskId: existingTaskId)
                }
            } else {
                try await forceEndAllTasks(endedBy: "camera_start")
                let newTaskId = try await createCameraTaskDoc(uid: uid, deviceID: did)
                activeTaskId = newTaskId
                activeTaskDeviceID = did
                mode = .broadcaster

                notifyOnMotionEnabled = notifyOnMotion
                try await startBroadcasting(uid: uid, taskId: newTaskId)
            }
        } catch {
            errorText = error.localizedDescription
            statusText = "error"
        }
    }

    func stopAndEndTask() async {
        stopWebRTC()

        guard let uid = userUID, let tid = activeTaskId else { return }
        if activeTaskDeviceID == localDeviceID {
            await endTaskDoc(uid: uid, taskId: tid, endedBy: "user_stop")
        }

        activeTaskId = nil
        activeTaskDeviceID = nil
        statusText = "stopped"
    }

    func flipCamera() {
        guard mode == .broadcaster else { return }
        currentPosition = (currentPosition == .front) ? .back : .front
        restartLocalCaptureForQuality()
    }

    // MARK: - Broadcaster

    private func startBroadcasting(uid: String, taskId: String) async throws {
        statusText = "starting camera…"

        let pc = makePeerConnection()
        peerConnection = pc

        // Add local track (capture + render local)
        try startWebRTCLocalCamera(on: pc)

        // Create offer
        statusText = "creating offer…"
        let constraints = RTCMediaConstraints(
            mandatoryConstraints: ["OfferToReceiveVideo": "false"],
            optionalConstraints: ["DtlsSrtpKeyAgreement": "true"]
        )

        let offer = try await pc.offer(for: constraints)
        try await pc.setLocalDescription(offer)
        try await setSignalingDoc(uid: uid, taskId: taskId, doc: WebRTCFields.offerDoc, sdp: offer)

        // Listen for answer
        listenForRemoteDescription(uid: uid, taskId: taskId, doc: WebRTCFields.answerDoc) { [weak self] sdp in
            guard let self else { return }
            Task { @MainActor in
                do {
                    try await self.peerConnection?.setRemoteDescription(sdp)
                    self.statusText = "broadcasting…"
                } catch {
                    self.errorText = error.localizedDescription
                }
            }
        }

        // Listen for callee ICE
        listenForIceCandidates(uid: uid, taskId: taskId, collection: WebRTCFields.calleeCandidates) { [weak self] candidate in
            self?.peerConnection?.add(candidate)
        }

        await logEvent(type: "broadcast_started", meta: ["pos": (currentPosition == .front ? "front" : "back")])
    }

    private func restartLocalCaptureForQuality() {
        guard mode == .broadcaster else { return }
        Task { @MainActor in
            do {
                try await localCapturer?.stopCapture()
                if let pc = peerConnection {
                    try startWebRTCLocalCamera(on: pc, replacing: true)
                }
                await logEvent(type: "camera_flipped", meta: ["pos": (currentPosition == .front ? "front" : "back")])
            } catch {
                // ignore
            }
        }
    }

    // MARK: - Viewer

    private func startViewing(uid: String, taskId: String) async throws {
        statusText = "connecting…"

        let pc = makePeerConnection()
        peerConnection = pc

        // Listen for offer
        listenForRemoteDescription(uid: uid, taskId: taskId, doc: WebRTCFields.offerDoc) { [weak self] offerSdp in
            guard let self else { return }
            Task { @MainActor in
                do {
                    try await self.peerConnection?.setRemoteDescription(offerSdp)

                    let constraints = RTCMediaConstraints(
                        mandatoryConstraints: ["OfferToReceiveVideo": "true"],
                        optionalConstraints: ["DtlsSrtpKeyAgreement": "true"]
                    )

                    guard let pc = self.peerConnection else { return }
                    let answer = try await pc.answer(for: constraints)
                    try await pc.setLocalDescription(answer)
                    try await self.setSignalingDoc(uid: uid, taskId: taskId, doc: WebRTCFields.answerDoc, sdp: answer)

                    await self.logEvent(type: "viewer_answer_sent")
                    self.statusText = "connecting…"
                } catch {
                    self.errorText = error.localizedDescription
                    self.statusText = "error"
                }
            }
        }

        // Listen for caller ICE
        listenForIceCandidates(uid: uid, taskId: taskId, collection: WebRTCFields.callerCandidates) { [weak self] candidate in
            self?.peerConnection?.add(candidate)
        }

        await logEvent(type: "viewer_waiting_offer")
    }

    // MARK: - WebRTC setup

    private func makePeerConnection() -> RTCPeerConnection {
        let config = RTCConfiguration()
        config.sdpSemantics = .unifiedPlan
        config.iceServers = [RTCIceServer(urlStrings: ["stun:stun.l.google.com:19302"])]
        config.continualGatheringPolicy = .gatherContinually

        let constraints = RTCMediaConstraints(
            mandatoryConstraints: nil,
            optionalConstraints: ["DtlsSrtpKeyAgreement": "true"]
        )

        let pc = rtcFactory.peerConnection(with: config, constraints: constraints, delegate: self)
        return pc!
    }

    /// Start local WebRTC capture using a safe format selection.
    private func startWebRTCLocalCamera(on pc: RTCPeerConnection, replacing: Bool = false) throws {
        if replacing == false {
            let source = rtcFactory.videoSource()
            localVideoSource = source

            let track = rtcFactory.videoTrack(with: source, trackId: "video0")
            localVideoTrack = track

            _ = pc.add(track, streamIds: ["stream0"])
            track.add(localRenderer)
        } else {
            localVideoTrack?.remove(localRenderer)
            localVideoTrack?.add(localRenderer)
        }

        guard let source = localVideoSource else {
            throw NSError(domain: "CameraTask", code: 510, userInfo: [NSLocalizedDescriptionKey: "Missing local video source."])
        }

        // Forward frames to the RTCVideoSource AND motion detector (simple, no extra pipelines).
        let detector = motionDetector ?? MotionDetector()
        motionDetector = detector

        let fwd = VideoFrameForwarder(target: source) { [weak self] frame in
            guard let self else { return }
            self.handleFrameForMotionIfNeeded(frame)
        }
        forwarder = fwd

        let capturer = RTCCameraVideoCapturer(delegate: fwd)
        localCapturer = capturer

        guard let device = RTCCameraVideoCapturer.captureDevices().first(where: { $0.position == currentPosition })
                ?? RTCCameraVideoCapturer.captureDevices().first else {
            throw NSError(domain: "CameraTask", code: 500, userInfo: [NSLocalizedDescriptionKey: "No camera device available."])
        }

        let format = chooseSafeFormat(for: device, preferredHeights: preferHeights)
        capturer.startCapture(with: device, format: format, fps: targetFps)
    }

    private func chooseSafeFormat(for device: AVCaptureDevice, preferredHeights: [Int32]) -> AVCaptureDevice.Format {
        let formats = RTCCameraVideoCapturer.supportedFormats(for: device)

        func height(_ f: AVCaptureDevice.Format) -> Int32 {
            CMVideoFormatDescriptionGetDimensions(f.formatDescription).height
        }

        for h in preferredHeights {
            if let match = formats.first(where: { height($0) == h }) {
                return match
            }
        }

        let under720 = formats.filter { height($0) <= 720 }
        if let best = under720.max(by: { height($0) < height($1) }) {
            return best
        }
        return formats.first!
    }

    // MARK: - Motion (simple + production-safe)

    private func handleFrameForMotionIfNeeded(_ frame: RTCVideoFrame) {
        guard mode == .broadcaster else { return }
        guard notifyOnMotionEnabled else { return }

        // If user is actively in the app on the capturing phone, don’t spam them with pushes.
        if UIApplication.shared.applicationState == .active { return }

        guard let detector = motionDetector else { return }
        if detector.process(frame: frame) {
            fireMotionNotification()
        }
    }

    private func fireMotionNotification() {
        guard let tid = activeTaskId else { return }

        // Keep it simple: a push + an event log.
        NotificationService.shared.sendPush(
            subject: "Motion detected",
            body: "Camera detected movement.",
            taskId: tid,
            eventType: "motion",
            sourceDeviceID: localDeviceID
        )

        Task { @MainActor in
            await logEvent(type: "motion", meta: [:])
        }
    }

    // MARK: - Stop / cleanup

    private func stopWebRTC() {
        signalingListeners.forEach { $0.remove() }
        signalingListeners.removeAll()

        localVideoTrack?.remove(localRenderer)
        localVideoTrack = nil
        localVideoSource = nil
        forwarder = nil
        motionDetector = nil

        Task { @MainActor in
            try? await localCapturer?.stopCapture()
            localCapturer = nil
        }

        peerConnection?.close()
        peerConnection = nil
    }

    // MARK: - Firestore task docs

    private func createCameraTaskDoc(uid: String, deviceID: String) async throws -> String {
        let ref = db.collection("users").document(uid).collection(TaskFields.collection).document()

        let cachedName = UserDefaults.standard.string(forKey: "local_device_name")
        let fallbackName = UIDevice.current.name
        let deviceName = (cachedName?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false)
            ? cachedName!
            : fallbackName

        let payload: [String: Any] = [
            TaskFields.name: "Camera",
            TaskFields.type: "camera",
            TaskFields.deviceID: deviceID,
            TaskFields.startedAt: Timestamp(date: Date()),
            TaskFields.endedAt: NSNull(),
            TaskFields.deviceName: deviceName,
            TaskFields.hasSamples: false
        ]

        try await ref.setData(payload, merge: true)
        return ref.documentID
    }

    private func endTaskDoc(uid: String, taskId: String, endedBy: String) async {
        let ref = db.collection("users").document(uid).collection(TaskFields.collection).document(taskId)
        do {
            try await ref.setData([
                TaskFields.endedAt: Timestamp(date: Date()),
                TaskFields.endedBy: endedBy,
                TaskFields.hasSamples: false
            ], merge: true)
        } catch { }
    }

    private func forceEndAllTasks(endedBy: String) async throws {
        guard let uid = Auth.auth().currentUser?.uid else {
            throw NSError(domain: "Auth", code: -1, userInfo: [NSLocalizedDescriptionKey: "No user logged in"])
        }

        let tasksRef = db.collection("users").document(uid).collection(TaskFields.collection)
        let now = FieldValue.serverTimestamp()

        func endDocs(_ docs: [QueryDocumentSnapshot]) async throws {
            guard !docs.isEmpty else { return }
            let batch = db.batch()
            for doc in docs {
                batch.updateData([
                    TaskFields.endedAt: now,
                    TaskFields.endedBy: endedBy
                ], forDocument: doc.reference)
            }
            try await batch.commit()
        }

        let snapNull = try await tasksRef.whereField(TaskFields.endedAt, isEqualTo: NSNull()).getDocuments()
        try await endDocs(snapNull.documents)

        let snapRecent = try await tasksRef.order(by: TaskFields.startedAt, descending: true).limit(to: 60).getDocuments()
        let missingEndedAtDocs = snapRecent.documents.filter { !$0.data().keys.contains(TaskFields.endedAt) }
        try await endDocs(missingEndedAtDocs)
    }

    private func logEvent(type: String, meta: [String: Any] = [:]) async {
        guard let uid = userUID, let taskId = activeTaskId else { return }
        let ref = db.collection("users").document(uid)
            .collection(TaskFields.collection).document(taskId)
            .collection(CameraEventFields.subcollection).document()

        do {
            try await ref.setData([
                CameraEventFields.t: Timestamp(date: Date()),
                CameraEventFields.type: type,
                CameraEventFields.meta: meta
            ], merge: true)
        } catch { }
    }

    // MARK: - Firestore signaling

    private func signalingBase(uid: String, taskId: String) -> CollectionReference {
        db.collection("users").document(uid)
            .collection(TaskFields.collection).document(taskId)
            .collection(WebRTCFields.subcollection)
    }

    private func setSignalingDoc(uid: String, taskId: String, doc: String, sdp: RTCSessionDescription) async throws {
        let ref = signalingBase(uid: uid, taskId: taskId).document(doc)
        try await ref.setData([
            WebRTCFields.type: sdp.type.stringValue,
            WebRTCFields.sdp: sdp.sdp,
            WebRTCFields.createdAt: FieldValue.serverTimestamp()
        ], merge: true)
    }

    private func listenForRemoteDescription(uid: String, taskId: String, doc: String, onSdp: @escaping (RTCSessionDescription) -> Void) {
        let ref = signalingBase(uid: uid, taskId: taskId).document(doc)
        let listener = ref.addSnapshotListener { snap, _ in
            guard let data = snap?.data(),
                  let sdpStr = data[WebRTCFields.sdp] as? String,
                  let typeStr = data[WebRTCFields.type] as? String else { return }

            let type: RTCSdpType = (typeStr == "offer") ? .offer : .answer
            onSdp(RTCSessionDescription(type: type, sdp: sdpStr))
        }
        signalingListeners.append(listener)
    }

    private func writeIceCandidate(uid: String, taskId: String, collection: String, candidate: RTCIceCandidate) {
        let ref = signalingBase(uid: uid, taskId: taskId)
            .document(collection)
            .collection("items")
            .document()

        ref.setData([
            "sdp": candidate.sdp,
            "sdpMLineIndex": candidate.sdpMLineIndex,
            "sdpMid": candidate.sdpMid as Any,
            WebRTCFields.createdAt: FieldValue.serverTimestamp()
        ], merge: true)
    }

    private func listenForIceCandidates(uid: String, taskId: String, collection: String, onCandidate: @escaping (RTCIceCandidate) -> Void) {
        let ref = signalingBase(uid: uid, taskId: taskId).document(collection).collection("items")
        let listener = ref.addSnapshotListener { snap, _ in
            guard let changes = snap?.documentChanges else { return }
            for change in changes where change.type == .added {
                let data = change.document.data()
                guard let sdp = data["sdp"] as? String,
                      let sdpMLineIndex = data["sdpMLineIndex"] as? Int else { continue }
                let sdpMid = data["sdpMid"] as? String
                onCandidate(RTCIceCandidate(sdp: sdp, sdpMLineIndex: Int32(sdpMLineIndex), sdpMid: sdpMid))
            }
        }
        signalingListeners.append(listener)
    }
}

// MARK: - WebRTC Delegates

extension CameraTaskController: RTCPeerConnectionDelegate {
    func peerConnection(_ peerConnection: RTCPeerConnection, didChange stateChanged: RTCSignalingState) { }
    func peerConnection(_ peerConnection: RTCPeerConnection, didAdd stream: RTCMediaStream) { }
    func peerConnection(_ peerConnection: RTCPeerConnection, didRemove stream: RTCMediaStream) { }
    func peerConnectionShouldNegotiate(_ peerConnection: RTCPeerConnection) { }

    func peerConnection(_ peerConnection: RTCPeerConnection, didChange newState: RTCIceConnectionState) {
        DispatchQueue.main.async {
            switch newState {
            case .connected, .completed:
                self.statusText = (self.mode == .broadcaster) ? "broadcasting…" : "live"
            case .checking:
                if self.mode == .viewer { self.statusText = "connecting…" }
            case .failed:
                self.statusText = "connection failed"
            case .disconnected:
                self.statusText = "disconnected"
            default:
                break
            }
        }
    }

    func peerConnection(_ peerConnection: RTCPeerConnection, didChange newState: RTCIceGatheringState) { }
    func peerConnection(_ peerConnection: RTCPeerConnection, didRemove candidates: [RTCIceCandidate]) { }
    func peerConnection(_ peerConnection: RTCPeerConnection, didOpen dataChannel: RTCDataChannel) { }

    func peerConnection(_ peerConnection: RTCPeerConnection, didGenerate candidate: RTCIceCandidate) {
        guard let uid = userUID, let taskId = activeTaskId else { return }
        let collection = (mode == .broadcaster) ? WebRTCFields.callerCandidates : WebRTCFields.calleeCandidates
        writeIceCandidate(uid: uid, taskId: taskId, collection: collection, candidate: candidate)
    }

    // Unified Plan: remote track callback
    func peerConnection(_ peerConnection: RTCPeerConnection,
                        didAdd rtpReceiver: RTCRtpReceiver,
                        streams: [RTCMediaStream]) {
        guard mode == .viewer else { return }
        if let track = rtpReceiver.track as? RTCVideoTrack {
            track.add(remoteRenderer)
            DispatchQueue.main.async {
                self.statusText = "live"
            }
        }
    }
}

// MARK: - Video Frame Forwarder

private final class VideoFrameForwarder: NSObject, RTCVideoCapturerDelegate {
    private let target: RTCVideoCapturerDelegate
    private let onFrame: (RTCVideoFrame) -> Void

    init(target: RTCVideoCapturerDelegate, onFrame: @escaping (RTCVideoFrame) -> Void) {
        self.target = target
        self.onFrame = onFrame
    }

    func capturer(_ capturer: RTCVideoCapturer, didCapture frame: RTCVideoFrame) {
        target.capturer(capturer, didCapture: frame)
        onFrame(frame)
    }
}

// MARK: - Motion Detector (simple + safe)

private final class MotionDetector {
    // Tunables (simple, no over-engineering)
    private let gridSize: Int = 24
    private let warmupFrames: Int = 20          // ~1.3s at 15fps
    private let consecutiveNeeded: Int = 3
    private let cooldownSeconds: TimeInterval = 60
    private let scoreThreshold: Double = 12.0   // tweak if too sensitive

    private var frameCount: Int = 0
    private var prev: [UInt8] = []
    private var consecutiveHits: Int = 0
    private var lastFire: Date = .distantPast

    func process(frame: RTCVideoFrame) -> Bool {
        frameCount += 1

        // Cooldown
        if Date().timeIntervalSince(lastFire) < cooldownSeconds {
            return false
        }

        guard let curr = sampleLumaGrid(frame: frame, gridSize: gridSize) else {
            // Skip this frame entirely (conversion not ready / format mismatch)
            return false
        }

        defer { prev = curr }

        // Warmup baseline
        if frameCount <= warmupFrames || prev.isEmpty || prev.count != curr.count {
            consecutiveHits = 0
            return false
        }

        // Mean absolute diff
        var sum: Int = 0
        for i in 0..<curr.count {
            sum += abs(Int(curr[i]) - Int(prev[i]))
        }
        let score = Double(sum) / Double(curr.count)

        if score > scoreThreshold {
            consecutiveHits += 1
        } else {
            consecutiveHits = 0
        }

        if consecutiveHits >= consecutiveNeeded {
            consecutiveHits = 0
            lastFire = Date()
            return true
        }

        return false
    }

    private func sampleLumaGrid(frame: RTCVideoFrame, gridSize: Int) -> [UInt8]? {
        // Convert to I420 and sample Y plane
        var i420 = frame.buffer.toI420()
        if frame.buffer.toI420() == nil {
            return nil
        } else {
            i420 = frame.buffer.toI420()
        }

        let width = Int(i420.width)
        let height = Int(i420.height)
        if width <= 0 || height <= 0 { return nil }

        let stepX = max(1, width / gridSize)
        let stepY = max(1, height / gridSize)

        let yStride = Int(i420.strideY)
        let yPtr = i420.dataY

        var out: [UInt8] = []
        out.reserveCapacity(gridSize * gridSize)

        // Sample a grid (top-left anchored)
        for gy in 0..<gridSize {
            let y = min(height - 1, gy * stepY)
            let row = yPtr.advanced(by: y * yStride)
            for gx in 0..<gridSize {
                let x = min(width - 1, gx * stepX)
                out.append(row[x])
            }
        }
        return out
    }
}

// MARK: - WebRTC Video View

private struct WebRTCVideoView: UIViewRepresentable {
    let renderer: (UIView & RTCVideoRenderer)

    func makeUIView(context: Context) -> UIView {
        let container = UIView()
        container.clipsToBounds = true

        renderer.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(renderer)
        NSLayoutConstraint.activate([
            renderer.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            renderer.trailingAnchor.constraint(equalTo: container.trailingAnchor),
            renderer.topAnchor.constraint(equalTo: container.topAnchor),
            renderer.bottomAnchor.constraint(equalTo: container.bottomAnchor)
        ])

        return container
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        // Swap renderer when mode changes (broadcaster ↔ viewer)
        guard uiView.subviews.first !== renderer else { return }

        uiView.subviews.forEach { $0.removeFromSuperview() }
        renderer.translatesAutoresizingMaskIntoConstraints = false
        uiView.addSubview(renderer)
        NSLayoutConstraint.activate([
            renderer.leadingAnchor.constraint(equalTo: uiView.leadingAnchor),
            renderer.trailingAnchor.constraint(equalTo: uiView.trailingAnchor),
            renderer.topAnchor.constraint(equalTo: uiView.topAnchor),
            renderer.bottomAnchor.constraint(equalTo: uiView.bottomAnchor)
        ])
    }
}

// MARK: - Async helpers for WebRTC offer/answer

private extension RTCPeerConnection {
    func offer(for constraints: RTCMediaConstraints) async throws -> RTCSessionDescription {
        try await withCheckedThrowingContinuation { cont in
            self.offer(for: constraints) { sdp, err in
                if let err { cont.resume(throwing: err); return }
                guard let sdp else {
                    cont.resume(throwing: NSError(domain: "WebRTC", code: -1, userInfo: [NSLocalizedDescriptionKey: "Offer was nil"]))
                    return
                }
                cont.resume(returning: sdp)
            }
        }
    }

    func answer(for constraints: RTCMediaConstraints) async throws -> RTCSessionDescription {
        try await withCheckedThrowingContinuation { cont in
            self.answer(for: constraints) { sdp, err in
                if let err { cont.resume(throwing: err); return }
                guard let sdp else {
                    cont.resume(throwing: NSError(domain: "WebRTC", code: -1, userInfo: [NSLocalizedDescriptionKey: "Answer was nil"]))
                    return
                }
                cont.resume(returning: sdp)
            }
        }
    }

    func setLocalDescription(_ sdp: RTCSessionDescription) async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            self.setLocalDescription(sdp) { err in
                if let err { cont.resume(throwing: err) }
                else { cont.resume(returning: ()) }
            }
        }
    }

    func setRemoteDescription(_ sdp: RTCSessionDescription) async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            self.setRemoteDescription(sdp) { err in
                if let err { cont.resume(throwing: err) }
                else { cont.resume(returning: ()) }
            }
        }
    }
}

private extension RTCSdpType {
    var stringValue: String {
        switch self {
        case .offer: return "offer"
        case .answer: return "answer"
        case .prAnswer: return "prAnswer"
        case .rollback: return "rollback"
        @unknown default: return "offer"
        }
    }
}
