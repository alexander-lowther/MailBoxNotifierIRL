
//
//  CameraTask.swift
//  Mail Box Notifer
//
//  High-quality WebRTC camera streaming (local + remote) + optional motion alerts.
//  Re-implemented to avoid AVCapture preview pipeline and use WebRTC capture/render end-to-end.
//
//  Notes:
//  - Broadcaster renders LOCAL WebRTC track (so you see what you stream).
//  - Viewer renders REMOTE track.
//  - Signaling via Firestore under task/webrtc/*
//  - Motion detection runs off captured RTCVideoFrame (no extra camera session).
//

import SwiftUI
import AVFoundation
import FirebaseAuth
import FirebaseFirestore
import UIKit
import CoreVideo
import CoreMedia
import WebRTC

// MARK: - Schema

private enum TaskFields {
    static let collection = "tasks"
    static let name = "name"
    static let type = "type"
    static let deviceID = "deviceID"
    static let startedAt = "startedAt"
    static let endedAt = "endedAt"
    static let endedBy = "endedBy"
    static let hasSamples = "hasSamples"
    static let deviceName = "deviceName"
}

private enum CameraEventFields {
    static let subcollection = "events"
    static let t = "t"
    static let type = "type"
    static let meta = "meta"
}

private enum WebRTCFields {
    static let subcollection = "webrtc"
    static let offerDoc = "offer"
    static let answerDoc = "answer"
    static let callerCandidates = "callerCandidates"
    static let calleeCandidates = "calleeCandidates"
    static let sdp = "sdp"
    static let type = "type"
    static let createdAt = "createdAt"
}

// MARK: - Setup View

struct CameraTaskSetupView: View {
    let functionTitle: String
    let deviceID: String
    @State private var notifyOnMotion: Bool = true

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(functionTitle)
                .font(.largeTitle.bold())

            Text("High-quality live remote camera feed + motion alerts.")
                .foregroundStyle(.secondary)

            Toggle("Notify on Motion", isOn: $notifyOnMotion)
                .tint(.green)

            Spacer()

            NavigationLink {
                CameraTaskLiveView(taskId: nil, notifyOnMotion: notifyOnMotion)
            } label: {
                Text("Start Camera")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.green.opacity(0.85))
                    .foregroundStyle(.black)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
            }
        }
        .padding()
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Live View

struct CameraTaskLiveView: View {
    /// nil = start NEW camera task (broadcaster)
    /// non-nil = open existing task (viewer if another device started it)
    let taskId: String?
    let notifyOnMotion: Bool

    @Environment(\.dismiss) private var dismiss
    @StateObject private var controller = CameraTaskController()

    @State private var statusText: String = "starting…"
    @State private var errorText: String?

    var body: some View {
        VStack(spacing: 12) {

            ZStack(alignment: .topLeading) {
                WebRTCVideoView(renderer: controller.activeRenderer)
                    .clipShape(RoundedRectangle(cornerRadius: 16))

                VStack(alignment: .leading, spacing: 6) {
                    Text(controller.mode == .broadcaster ? "Camera (Broadcasting)" : "Camera (Viewing)")
                        .font(.headline)
                    Text(statusText)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(10)
                .background(.thinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .padding(10)
            }
            .frame(maxWidth: .infinity)
            .aspectRatio(9/16, contentMode: .fit)

            if let errorText {
                Text(errorText)
                    .foregroundStyle(.red)
                    .font(.footnote)
            }

            HStack(spacing: 10) {

                if controller.mode == .broadcaster {
                    Button {
                        controller.flipCamera()
                    } label: {
                        Label("Flip", systemImage: "camera.rotate")
                    }
                    .buttonStyle(.bordered)
                }

                Spacer()

                Button(role: .destructive) {
                    Task {
                        await controller.stopAndEndTask()
                        dismiss()
                    }
                } label: {
                    Label("Stop", systemImage: "stop.fill")
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .padding()
        .navigationTitle("Live")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            Task {
                do {
                    try await controller.start(existingTaskId: taskId, notifyOnMotion: notifyOnMotion)
                    statusText = (controller.mode == .broadcaster) ? "broadcasting…" : "connecting…"
                } catch {
                    errorText = error.localizedDescription
                    statusText = "error"
                }
            }
        }
        .onDisappear {
            // No-op; Stop button ends task explicitly.
        }
    }
}

// MARK: - Controller

@MainActor
final class CameraTaskController: NSObject, ObservableObject {

    enum Mode { case broadcaster, viewer }

    @Published private(set) var mode: Mode = .broadcaster

    // Firestore
    private let db = Firestore.firestore()
    private var userUID: String?
    private var localDeviceID: String?
    private var activeTaskId: String?
    private var activeTaskDeviceID: String?

    // WebRTC Factory
    private let rtcFactory: RTCPeerConnectionFactory = {
        RTCInitializeSSL()
        let encoderFactory = RTCDefaultVideoEncoderFactory()
        let decoderFactory = RTCDefaultVideoDecoderFactory()
        return RTCPeerConnectionFactory(encoderFactory: encoderFactory, decoderFactory: decoderFactory)
    }()

    // WebRTC Core
    private var peerConnection: RTCPeerConnection?
    private var signalingListeners: [ListenerRegistration] = []

    // Tracks / Capturer
    private var localVideoSource: RTCVideoSource?
    private var localVideoTrack: RTCVideoTrack?
    private var localCapturer: RTCCameraVideoCapturer?
    private var currentPosition: AVCaptureDevice.Position = .front

    // Renderers
    private let localRenderer = RTCMTLVideoView()
    private let remoteRenderer = RTCMTLVideoView()

    var activeRenderer: RTCMTLVideoView {
        (mode == .broadcaster) ? localRenderer : remoteRenderer
    }

    // Motion detection
    private var notifyOnMotion: Bool = true
    private var previousGrid: [UInt8]?
    private var inMotion: Bool = false
    private var lastNotifyAt: Date = .distantPast
    private var quietSince: Date?

    // Anti-spam tuning
    private let gridSize: Int = 14
    private let motionDiffThreshold: Double = 0.12
    private let quietDiffThreshold: Double = 0.05
    private let quietRearmSeconds: TimeInterval = 2.0
    private let cooldownSeconds: TimeInterval = 30.0

    // Quality tuning (sender)
    private let targetMaxBitrateBps: Int = 1_800_000      // ~1.8 Mbps
    private let targetMaxFps: Int = 30
    private let targetMinHeight: Int32 = 720              // prefer >=720p where available

    // MARK: - Public

    func start(existingTaskId: String?, notifyOnMotion: Bool) async throws {
        self.notifyOnMotion = notifyOnMotion

        guard let uid = Auth.auth().currentUser?.uid else {
            throw NSError(domain: "CameraTask", code: 401, userInfo: [NSLocalizedDescriptionKey: "Not signed in."])
        }
        self.userUID = uid

        let did = UserDefaults.standard.string(forKey: "deviceID") ?? {
            let new = UUID().uuidString
            UserDefaults.standard.set(new, forKey: "deviceID")
            return new
        }()
        self.localDeviceID = did

        // Prepare renderers
        localRenderer.videoContentMode = .scaleAspectFill
        remoteRenderer.videoContentMode = .scaleAspectFill

        if let existingTaskId {
            self.activeTaskId = existingTaskId

            let taskDoc = try await db.collection("users").document(uid)
                .collection(TaskFields.collection).document(existingTaskId).getDocument()

            guard let data = taskDoc.data(),
                  let ownerDeviceID = data[TaskFields.deviceID] as? String else {
                throw NSError(domain: "CameraTask", code: 404, userInfo: [NSLocalizedDescriptionKey: "Task not found or missing deviceID."])
            }

            self.activeTaskDeviceID = ownerDeviceID
            self.mode = (ownerDeviceID == did) ? .broadcaster : .viewer

            if self.mode == .broadcaster {
                try await startBroadcasting(uid: uid, taskId: existingTaskId)
            } else {
                try await startViewing(uid: uid, taskId: existingTaskId)
            }
        } else {
            try await forceEndAllTasks(endedBy: "camera_start")
            let newTaskId = try await createCameraTaskDoc(uid: uid, deviceID: did)
            self.activeTaskId = newTaskId
            self.activeTaskDeviceID = did
            self.mode = .broadcaster
            try await startBroadcasting(uid: uid, taskId: newTaskId)
        }
    }

    func stopAndEndTask() async {
        stopWebRTC()

        previousGrid = nil
        inMotion = false
        quietSince = nil

        guard let uid = userUID, let tid = activeTaskId else { return }
        if activeTaskDeviceID == localDeviceID {
            await endTaskDoc(uid: uid, taskId: tid, endedBy: "user_stop")
        }

        activeTaskId = nil
        activeTaskDeviceID = nil
    }

    func flipCamera() {
        guard mode == .broadcaster else { return }
        currentPosition = (currentPosition == .front) ? .back : .front
        restartLocalCaptureForQuality()
    }

    // MARK: - Broadcaster

    private func startBroadcasting(uid: String, taskId: String) async throws {
        let pc = makePeerConnection(uid: uid, taskId: taskId, isCaller: true)
        self.peerConnection = pc

        // Add local track (capture + render local)
        try startWebRTCLocalCamera(on: pc)

        // Create offer
        let constraints = RTCMediaConstraints(
            mandatoryConstraints: ["OfferToReceiveVideo": "false"],
            optionalConstraints: ["DtlsSrtpKeyAgreement": "true"]
        )

        let offer = try await pc.offer(for: constraints)
        try await pc.setLocalDescription(offer)

        try await setSignalingDoc(uid: uid, taskId: taskId, doc: WebRTCFields.offerDoc, sdp: offer)

        // Listen for answer
        listenForRemoteDescription(uid: uid, taskId: taskId, doc: WebRTCFields.answerDoc) { [weak self] sdp in
            guard let self else { return }
            Task { @MainActor in
                do { try await self.peerConnection?.setRemoteDescription(sdp) } catch { }
            }
        }

        // Listen for callee ICE
        listenForIceCandidates(uid: uid, taskId: taskId, collection: WebRTCFields.calleeCandidates) { [weak self] candidate in
            self?.peerConnection?.add(candidate)
        }

        await logEvent(type: "broadcast_started", meta: ["pos": (currentPosition == .front ? "front" : "back")])
    }

    private func restartLocalCaptureForQuality() {
        guard mode == .broadcaster else { return }
        Task { @MainActor in
            do {
                // Stop + restart capture with a better chosen format for the new camera position
                try await localCapturer?.stopCapture()
                if let pc = peerConnection {
                    try startWebRTCLocalCamera(on: pc, replacing: true)
                }
                await logEvent(type: "camera_flipped", meta: ["pos": (currentPosition == .front ? "front" : "back")])
            } catch {
                // ignore
            }
        }
    }

    // MARK: - Viewer

    private func startViewing(uid: String, taskId: String) async throws {
        let pc = makePeerConnection(uid: uid, taskId: taskId, isCaller: false)
        self.peerConnection = pc

        // Listen for offer
        listenForRemoteDescription(uid: uid, taskId: taskId, doc: WebRTCFields.offerDoc) { [weak self] offerSdp in
            guard let self else { return }
            Task { @MainActor in
                do {
                    try await self.peerConnection?.setRemoteDescription(offerSdp)

                    let constraints = RTCMediaConstraints(
                        mandatoryConstraints: ["OfferToReceiveVideo": "true"],
                        optionalConstraints: ["DtlsSrtpKeyAgreement": "true"]
                    )

                    let answer = try await self.peerConnection?.answer(for: constraints)
                    try await self.peerConnection?.setLocalDescription(answer!)
                    try await self.setSignalingDoc(uid: uid, taskId: taskId, doc: WebRTCFields.answerDoc, sdp: answer!)

                    await self.logEvent(type: "viewer_answer_sent")
                } catch {
                    // ignore
                }
            }
        }

        // Listen for caller ICE
        listenForIceCandidates(uid: uid, taskId: taskId, collection: WebRTCFields.callerCandidates) { [weak self] candidate in
            self?.peerConnection?.add(candidate)
        }

        await logEvent(type: "viewer_waiting_offer")
    }

    // MARK: - WebRTC setup (quality-focused)

    private func makePeerConnection(uid: String, taskId: String, isCaller: Bool) -> RTCPeerConnection {
        let config = RTCConfiguration()
        config.sdpSemantics = .unifiedPlan

        // STUN only (TURN recommended for real-world NAT traversal).
        config.iceServers = [
            RTCIceServer(urlStrings: ["stun:stun.l.google.com:19302"])
        ]

        // Prefer stable quality over ultra-low-latency spikes.
        config.continualGatheringPolicy = .gatherContinually

        let constraints = RTCMediaConstraints(
            mandatoryConstraints: nil,
            optionalConstraints: ["DtlsSrtpKeyAgreement": "true"]
        )

        let pc = rtcFactory.peerConnection(with: config, constraints: constraints, delegate: self)
        return pc!
    }

    /// Start local WebRTC capture using a high-quality format selection.
    private func startWebRTCLocalCamera(on pc: RTCPeerConnection, replacing: Bool = false) throws {
        // If replacing, keep the existing track attached to senders; otherwise create new track.
        if replacing == false {
            let source = rtcFactory.videoSource()
            self.localVideoSource = source

            let track = rtcFactory.videoTrack(with: source, trackId: "video0")
            self.localVideoTrack = track

            // Add to PC
            _ = pc.add(track, streamIds: ["stream0"])

            // Render local preview from the same track you stream.
            track.add(localRenderer)
        } else {
            // Keep existing renderer/track; we only restart capturer with new device/format.
            localVideoTrack?.remove(localRenderer)
            localVideoTrack?.add(localRenderer)
        }

        // Capture
        guard let source = localVideoSource else {
            throw NSError(domain: "CameraTask", code: 510, userInfo: [NSLocalizedDescriptionKey: "Missing local video source."])
        }

        let delegate = MultiCapturerDelegate(videoSource: source) { [weak self] frame in
            self?.analyzeFrameForMotion(frame)
        }

        let capturer = RTCCameraVideoCapturer(delegate: delegate)
        self.localCapturer = capturer

        // Choose best device for currentPosition
        guard let device = RTCCameraVideoCapturer.captureDevices().first(where: { $0.position == currentPosition })
                ?? RTCCameraVideoCapturer.captureDevices().first else {
            throw NSError(domain: "CameraTask", code: 500, userInfo: [NSLocalizedDescriptionKey: "No camera device available."])
        }

        // Pick best format (prefer >=720p, then highest fps support)
        let format = chooseBestFormat(for: device, preferMinHeight: targetMinHeight)
        let fps = chooseBestFps(for: format, prefer: targetMaxFps)

        capturer.startCapture(with: device, format: format, fps: fps)

        // Apply sender encoding hints (bitrate/fps) for better quality.
        applySenderQualityHints()

        // Also request camera device focus/exposure where possible (helps perceived quality).
        configureDeviceQualityIfPossible(device: device)
    }

    private func applySenderQualityHints() {
        guard let pc = peerConnection else { return }

        for sender in pc.senders {
            guard let track = sender.track as? RTCVideoTrack else { continue }
            guard track == localVideoTrack else { continue }

            let params = sender.parameters
            if params.encodings.isEmpty {
                params.encodings = [RTCRtpEncodingParameters]()
            }
            if params.encodings.isEmpty {
                params.encodings = [RTCRtpEncodingParameters]()
            }

            // Ensure at least one encoding.
            if params.encodings.isEmpty {
                params.encodings = [RTCRtpEncodingParameters]()
                params.encodings.append(RTCRtpEncodingParameters())
            }

            let enc = params.encodings[0]
            enc.isActive = true
            enc.maxBitrateBps = NSNumber(value: targetMaxBitrateBps)
            enc.maxFramerate = NSNumber(value: targetMaxFps)
            enc.scaleResolutionDownBy = NSNumber(value: 1.0)

            sender.parameters = params
        }
    }

    private func configureDeviceQualityIfPossible(device: AVCaptureDevice) {
        do {
            try device.lockForConfiguration()
            defer { device.unlockForConfiguration() }

            // Continuous AF/AE gives better sharpness + less pumping.
            if device.isFocusModeSupported(.continuousAutoFocus) {
                device.focusMode = .continuousAutoFocus
            }
            if device.isExposureModeSupported(.continuousAutoExposure) {
                device.exposureMode = .continuousAutoExposure
            }
            if device.isWhiteBalanceModeSupported(.continuousAutoWhiteBalance) {
                device.whiteBalanceMode = .continuousAutoWhiteBalance
            }

            // If supported, bias toward quality.
            if device.activeFormat.isVideoStabilizationModeSupported(.cinematic) {
                // Stabilization is applied at connection level in AVCapture; WebRTC uses AVCapture internally.
                // No direct toggle here; we keep AF/AE on, which helps quality most.
            }
        } catch {
            // ignore
        }
    }

    private func chooseBestFormat(for device: AVCaptureDevice, preferMinHeight: Int32) -> AVCaptureDevice.Format {
        let formats = RTCCameraVideoCapturer.supportedFormats(for: device)

        func dims(_ f: AVCaptureDevice.Format) -> (w: Int32, h: Int32) {
            let d = CMVideoFormatDescriptionGetDimensions(f.formatDescription)
            return (d.width, d.height)
        }

        // Score: prefer >=720p, then max resolution, then max fps.
        var best: AVCaptureDevice.Format = formats.first!
        var bestScore: Double = -Double.greatestFiniteMagnitude

        for f in formats {
            let (w, h) = dims(f)
            let pixels = Double(w) * Double(h)

            let fpsMax = f.videoSupportedFrameRateRanges.map { $0.maxFrameRate }.max() ?? 0
            let meetsMin = (h >= preferMinHeight) ? 1.0 : 0.0

            // Weighting tuned for “looks good” over raw fps.
            let score = meetsMin * 1_000_000_000
                + pixels
                + fpsMax * 10_000

            if score > bestScore {
                bestScore = score
                best = f
            }
        }

        return best
    }

    private func chooseBestFps(for format: AVCaptureDevice.Format, prefer: Int) -> Int {
        let ranges = format.videoSupportedFrameRateRanges
        let maxFps = Int(ranges.map { $0.maxFrameRate }.max() ?? Double(prefer))
        return min(maxFps, prefer)
    }

    // MARK: - Motion detection on RTC frames (no extra capture pipeline)

    private func analyzeFrameForMotion(_ frame: RTCVideoFrame) {
        guard mode == .broadcaster else { return }
        guard notifyOnMotion else { return }

        // Convert to I420 for fast luma sampling
        let buffer = frame.buffer
        let i420 = buffer.toI420()

       

        // Convert to I420 for fast luma sampling
 


        let width = Int(i420.width)
        let height = Int(i420.height)
        guard width > 0, height > 0 else { return }

        let stepX = max(width / gridSize, 1)
        let stepY = max(height / gridSize, 1)

        var curr: [UInt8] = []
        curr.reserveCapacity(gridSize * gridSize)

        // Y plane (luma)
        let yStride = Int(i420.strideY)
        
        let yPtr = i420.dataY 

        // Ensure we are working with a byte pointer
        let yBase = UnsafeMutableRawPointer(mutating: yPtr).assumingMemoryBound(to: UInt8.self)

        for y in stride(from: 0, to: height, by: stepY) {
            let row = yBase.advanced(by: y * yStride)
            for x in stride(from: 0, to: width, by: stepX) {
                let luma = row[x]
                curr.append(luma)
                if curr.count >= gridSize * gridSize { break }
            }
            if curr.count >= gridSize * gridSize { break }
        }

        guard !curr.isEmpty else { return }

        if let prev = previousGrid, prev.count == curr.count {
            var sumDiff: Double = 0
            for i in 0..<curr.count {
                sumDiff += Double(abs(Int(curr[i]) - Int(prev[i]))) / 255.0
            }
            let avgDiff = sumDiff / Double(curr.count)
            handleMotion(diff: avgDiff)
        }

        previousGrid = curr
    }

    private func handleMotion(diff: Double) {
        let now = Date()

        if diff >= motionDiffThreshold {
            quietSince = nil

            if !inMotion {
                inMotion = true

                if now.timeIntervalSince(lastNotifyAt) >= cooldownSeconds {
                    lastNotifyAt = now
                    Task { @MainActor in
                        await self.logEvent(type: "motion_started", meta: ["diff": diff])
                        NotificationService.shared.sendPush(
                            subject: "Motion detected",
                            body: "Camera detected movement.",
                            taskId: self.activeTaskId,
                            eventType: "motion_detected",
                            sourceDeviceID: self.localDeviceID
                        )
                    }
                } else {
                    Task { @MainActor in
                        await self.logEvent(type: "motion_started_suppressed", meta: ["diff": diff])
                    }
                }
            }
            return
        }

        if diff <= quietDiffThreshold {
            if quietSince == nil { quietSince = now }

            if inMotion, let qs = quietSince, now.timeIntervalSince(qs) >= quietRearmSeconds {
                inMotion = false
                Task { @MainActor in
                    await self.logEvent(type: "motion_ended")
                }
            }
        } else {
            quietSince = nil
        }
    }

    // MARK: - Stop / cleanup

    private func stopWebRTC() {
        signalingListeners.forEach { $0.remove() }
        signalingListeners.removeAll()

        localVideoTrack?.remove(localRenderer)
        localVideoTrack = nil
        localVideoSource = nil

        Task { @MainActor in
            try? await localCapturer?.stopCapture()
            localCapturer = nil
        }

        peerConnection?.close()
        peerConnection = nil
    }

    // MARK: - Firestore task docs

    private func createCameraTaskDoc(uid: String, deviceID: String) async throws -> String {
        let ref = db.collection("users").document(uid).collection(TaskFields.collection).document()

        let cachedName = UserDefaults.standard.string(forKey: "local_device_name")
        let fallbackName = UIDevice.current.name
        let deviceName = (cachedName?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false)
            ? cachedName!
            : fallbackName

        let payload: [String: Any] = [
            TaskFields.name: "Camera",
            TaskFields.type: "camera",
            TaskFields.deviceID: deviceID,
            TaskFields.startedAt: Timestamp(date: Date()),
            TaskFields.endedAt: NSNull(),
            TaskFields.deviceName: deviceName,
            TaskFields.hasSamples: false
        ]

        try await ref.setData(payload, merge: true)
        return ref.documentID
    }

    private func endTaskDoc(uid: String, taskId: String, endedBy: String) async {
        let ref = db.collection("users").document(uid).collection(TaskFields.collection).document(taskId)
        do {
            try await ref.setData([
                TaskFields.endedAt: Timestamp(date: Date()),
                TaskFields.endedBy: endedBy,
                TaskFields.hasSamples: false
            ], merge: true)
        } catch { }
    }

    private func forceEndAllTasks(endedBy: String) async throws {
        guard let uid = Auth.auth().currentUser?.uid else {
            throw NSError(domain: "Auth", code: -1, userInfo: [NSLocalizedDescriptionKey: "No user logged in"])
        }

        let tasksRef = db.collection("users").document(uid).collection(TaskFields.collection)
        let now = FieldValue.serverTimestamp()

        func endDocs(_ docs: [QueryDocumentSnapshot]) async throws {
            guard !docs.isEmpty else { return }
            let batch = db.batch()
            for doc in docs {
                batch.updateData([
                    TaskFields.endedAt: now,
                    TaskFields.endedBy: endedBy
                ], forDocument: doc.reference)
            }
            try await batch.commit()
        }

        let snapNull = try await tasksRef.whereField(TaskFields.endedAt, isEqualTo: NSNull()).getDocuments()
        try await endDocs(snapNull.documents)

        let snapRecent = try await tasksRef.order(by: TaskFields.startedAt, descending: true).limit(to: 60).getDocuments()
        let missingEndedAtDocs = snapRecent.documents.filter { !$0.data().keys.contains(TaskFields.endedAt) }
        try await endDocs(missingEndedAtDocs)
    }

    private func logEvent(type: String, meta: [String: Any] = [:]) async {
        guard let uid = userUID, let taskId = activeTaskId else { return }
        let ref = db.collection("users").document(uid)
            .collection(TaskFields.collection).document(taskId)
            .collection(CameraEventFields.subcollection).document()

        do {
            try await ref.setData([
                CameraEventFields.t: Timestamp(date: Date()),
                CameraEventFields.type: type,
                CameraEventFields.meta: meta
            ], merge: true)
        } catch { }
    }

    // MARK: - Firestore signaling

    private func signalingBase(uid: String, taskId: String) -> CollectionReference {
        db.collection("users").document(uid)
            .collection(TaskFields.collection).document(taskId)
            .collection(WebRTCFields.subcollection)
    }

    private func setSignalingDoc(uid: String, taskId: String, doc: String, sdp: RTCSessionDescription) async throws {
        let ref = signalingBase(uid: uid, taskId: taskId).document(doc)
        try await ref.setData([
            WebRTCFields.type: sdp.type.stringValue,
            WebRTCFields.sdp: sdp.sdp,
            WebRTCFields.createdAt: FieldValue.serverTimestamp()
        ], merge: true)
    }

    private func listenForRemoteDescription(uid: String, taskId: String, doc: String, onSdp: @escaping (RTCSessionDescription) -> Void) {
        let ref = signalingBase(uid: uid, taskId: taskId).document(doc)
        let listener = ref.addSnapshotListener { snap, _ in
            guard let data = snap?.data(),
                  let sdpStr = data[WebRTCFields.sdp] as? String,
                  let typeStr = data[WebRTCFields.type] as? String else { return }

            let type: RTCSdpType = (typeStr == "offer") ? .offer : .answer
            onSdp(RTCSessionDescription(type: type, sdp: sdpStr))
        }
        signalingListeners.append(listener)
    }

    private func writeIceCandidate(uid: String, taskId: String, collection: String, candidate: RTCIceCandidate) {
        let ref = signalingBase(uid: uid, taskId: taskId)
            .document(collection)
            .collection("items")
            .document()

        ref.setData([
            "sdp": candidate.sdp,
            "sdpMLineIndex": candidate.sdpMLineIndex,
            "sdpMid": candidate.sdpMid as Any,
            WebRTCFields.createdAt: FieldValue.serverTimestamp()
        ], merge: true)
    }

    private func listenForIceCandidates(uid: String, taskId: String, collection: String, onCandidate: @escaping (RTCIceCandidate) -> Void) {
        let ref = signalingBase(uid: uid, taskId: taskId).document(collection).collection("items")
        let listener = ref.addSnapshotListener { snap, _ in
            guard let changes = snap?.documentChanges else { return }
            for change in changes where change.type == .added {
                let data = change.document.data()
                guard let sdp = data["sdp"] as? String,
                      let sdpMLineIndex = data["sdpMLineIndex"] as? Int else { continue }
                let sdpMid = data["sdpMid"] as? String
                onCandidate(RTCIceCandidate(sdp: sdp, sdpMLineIndex: Int32(sdpMLineIndex), sdpMid: sdpMid))
            }
        }
        signalingListeners.append(listener)
    }
}

// MARK: - WebRTC Delegates

extension CameraTaskController: RTCPeerConnectionDelegate {

    func peerConnection(_ peerConnection: RTCPeerConnection, didChange stateChanged: RTCSignalingState) { }
    func peerConnection(_ peerConnection: RTCPeerConnection, didAdd stream: RTCMediaStream) { }
    func peerConnection(_ peerConnection: RTCPeerConnection, didRemove stream: RTCMediaStream) { }
    func peerConnectionShouldNegotiate(_ peerConnection: RTCPeerConnection) { }
    func peerConnection(_ peerConnection: RTCPeerConnection, didChange newState: RTCIceConnectionState) { }
    func peerConnection(_ peerConnection: RTCPeerConnection, didChange newState: RTCIceGatheringState) { }
    func peerConnection(_ peerConnection: RTCPeerConnection, didRemove candidates: [RTCIceCandidate]) { }
    func peerConnection(_ peerConnection: RTCPeerConnection, didOpen dataChannel: RTCDataChannel) { }

    func peerConnection(_ peerConnection: RTCPeerConnection, didGenerate candidate: RTCIceCandidate) {
        guard let uid = userUID, let taskId = activeTaskId else { return }
        let collection = (mode == .broadcaster) ? WebRTCFields.callerCandidates : WebRTCFields.calleeCandidates
        writeIceCandidate(uid: uid, taskId: taskId, collection: collection, candidate: candidate)
    }

    // Unified Plan: remote track callback
    func peerConnection(_ peerConnection: RTCPeerConnection,
                        didAdd rtpReceiver: RTCRtpReceiver,
                        streams: [RTCMediaStream]) {
        guard mode == .viewer else { return }
        if let track = rtpReceiver.track as? RTCVideoTrack {
            track.add(remoteRenderer)
        }
    }
}

// MARK: - Capturer delegate multiplexer

/// WebRTC wants ONE delegate (the RTCVideoSource), but we also want frames for motion.
/// This forwards frames into the RTCVideoSource AND calls `onFrame` for analysis.
private final class MultiCapturerDelegate: NSObject, RTCVideoCapturerDelegate {
    private let videoSource: RTCVideoSource
    private let onFrame: (RTCVideoFrame) -> Void

    init(videoSource: RTCVideoSource, onFrame: @escaping (RTCVideoFrame) -> Void) {
        self.videoSource = videoSource
        self.onFrame = onFrame
        super.init()
    }

    func capturer(_ capturer: RTCVideoCapturer, didCapture frame: RTCVideoFrame) {
        videoSource.capturer(capturer, didCapture: frame)
        onFrame(frame)
    }
}

// MARK: - WebRTC Video View

private struct WebRTCVideoView: UIViewRepresentable {
    let renderer: RTCMTLVideoView

    func makeUIView(context: Context) -> RTCMTLVideoView {
        renderer.videoContentMode = .scaleAspectFill
        return renderer
    }

    func updateUIView(_ uiView: RTCMTLVideoView, context: Context) { }
}

// MARK: - Async helpers for WebRTC offer/answer

private extension RTCPeerConnection {
    func offer(for constraints: RTCMediaConstraints) async throws -> RTCSessionDescription {
        try await withCheckedThrowingContinuation { cont in
            self.offer(for: constraints) { sdp, err in
                if let err { cont.resume(throwing: err); return }
                guard let sdp else {
                    cont.resume(throwing: NSError(domain: "WebRTC", code: -1, userInfo: [NSLocalizedDescriptionKey: "Offer was nil"]))
                    return
                }
                cont.resume(returning: sdp)
            }
        }
    }

    func answer(for constraints: RTCMediaConstraints) async throws -> RTCSessionDescription {
        try await withCheckedThrowingContinuation { cont in
            self.answer(for: constraints) { sdp, err in
                if let err { cont.resume(throwing: err); return }
                guard let sdp else {
                    cont.resume(throwing: NSError(domain: "WebRTC", code: -1, userInfo: [NSLocalizedDescriptionKey: "Answer was nil"]))
                    return
                }
                cont.resume(returning: sdp)
            }
        }
    }

    func setLocalDescription(_ sdp: RTCSessionDescription) async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            self.setLocalDescription(sdp) { err in
                if let err { cont.resume(throwing: err) }
                else { cont.resume(returning: ()) }
            }
        }
    }

    func setRemoteDescription(_ sdp: RTCSessionDescription) async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            self.setRemoteDescription(sdp) { err in
                if let err { cont.resume(throwing: err) }
                else { cont.resume(returning: ()) }
            }
        }
    }
}

private extension RTCSdpType {
    var stringValue: String {
        switch self {
        case .offer: return "offer"
        case .answer: return "answer"
        case .prAnswer: return "prAnswer"
        case .rollback: return "rollback"
        @unknown default: return "offer"
        }
    }
}
