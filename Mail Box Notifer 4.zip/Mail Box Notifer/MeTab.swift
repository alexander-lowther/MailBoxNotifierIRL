
import SwiftUI
import FirebaseAuth
import FirebaseFirestore
import FirebaseFunctions

struct MeView: View {
    let userUID: String
    private let db = Firestore.firestore()

    @State private var email: String = ""
    @State private var displayName: String = ""
    @State private var providerSummary: String = ""

    @State private var showSignOutConfirm: Bool = false
    @State private var showDeleteConfirm: Bool = false

    // Minimal, non-invasive surface for failures (keeps UI stable)
    @State private var deleteErrorText: String? = nil
    @State private var isDeleting: Bool = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {

                    accountCard

                    if let deleteErrorText {
                        Text(deleteErrorText)
                            .font(.footnote)
                            .foregroundStyle(.red)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }

                    Button(role: .destructive) {
                        showSignOutConfirm = true
                    } label: {
                        Label("Sign Out", systemImage: "rectangle.portrait.and.arrow.right")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                    .padding(.top, 4)
                    .disabled(isDeleting)

                    Button(role: .destructive) {
                        showDeleteConfirm = true
                    } label: {
                        Label(isDeleting ? "Deleting…" : "Delete User", systemImage: "trash")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                    .padding(.top, 4)
                    .disabled(isDeleting)

                    Spacer(minLength: 8)
                }
                .padding()
            }
            .navigationTitle("Me")
            .navigationBarTitleDisplayMode(.large)
            .onAppear {
                hydrateFromAuth()
            }
            .confirmationDialog(
                "Sign out of this device?",
                isPresented: $showSignOutConfirm,
                titleVisibility: .visible
            ) {
                Button("Sign Out", role: .destructive) {
                    signOut()
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("You will need to sign in again to use this app on this device.")
            }
            .confirmationDialog(
                "Delete this account?",
                isPresented: $showDeleteConfirm,
                titleVisibility: .visible
            ) {
                Button("Delete Account", role: .destructive) {
                    deleteErrorText = nil
                  
                    db.collection("users").document(userUID).delete()
                    
                   
                            signOut()
                      
                       
                    
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("This permanently deletes your account and all associated data.")
            }
        }
    }

    // MARK: - UI Cards

    private var accountCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Account Details")
                .font(.headline)

            row("Email", value: email.isEmpty ? "Not available" : email)
            row("Provider", value: providerSummary.isEmpty ? "Unknown" : providerSummary)
        }
        .padding(14)
        .background(AppTheme.surface)
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .strokeBorder(.primary.opacity(0.08), lineWidth: 1)
        )
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private func row(_ title: String, value: String) -> some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title)
                .font(.subheadline.weight(.semibold))
            Spacer()
            Text(value)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.trailing)
                .lineLimit(2)
        }
        .padding(.vertical, 4)
    }

    // MARK: - Auth hydration

    private func hydrateFromAuth() {
        guard let user = Auth.auth().currentUser else {
            email = ""
            displayName = ""
            providerSummary = ""
            return
        }

        email = user.email ?? ""
        displayName = user.displayName ?? ""

        let providers = user.providerData.map { $0.providerID }
        providerSummary = providers.isEmpty ? "Unknown" : providers.joined(separator: ", ")
    }

    // MARK: - Sign out

    private func signOut() {
        do {
            try Auth.auth().signOut()
        } catch {
            // keeping it silent to avoid UI churn
        }
        UserDefaults.standard.removeObject(forKey: "userUID")
    }

    // MARK: - Deletion (ROCK SOLID)

    /// Firebase "recent sign-in" should be checked using Auth metadata, not a Firestore timestamp.
    private func hasAuthRecentlySignedIn(within seconds: TimeInterval = 300) -> Bool {
        guard let user = Auth.auth().currentUser else { return false }
        guard let lastSignIn = user.metadata.lastSignInDate else { return false }
        return Date().timeIntervalSince(lastSignIn) <= seconds
    }

    /// Server-side delete of `/users/{uid}` subtree.
    /// Requires a callable Cloud Function named `deleteAccountData`.
    private func deleteFirestoreUserData(completion: @escaping (Bool, String?) -> Void) {
        let functions = Functions.functions()
        functions.httpsCallable("deleteAccountData").call { _, error in
            if let error {
                completion(false, "Could not delete cloud data: \(error.localizedDescription)")
                return
            }
            completion(true, nil)
        }
    }

    /// Full account deletion flow:
    /// 1) Ensure auth is recent enough (otherwise deletion will fail).
    /// 2) Delete Firestore subtree via callable function.
    /// 3) Delete Firebase Auth user.
    /// 4) Caller signs out locally on success.
    private func deleteAccountFlow(completion: @escaping (Bool, String?) -> Void) {
        guard let user = Auth.auth().currentUser else {
            completion(true, nil)
            return
        }

        // Prevent double-taps and re-entrancy
        guard !isDeleting else { return }
        isDeleting = true

        // IMPORTANT: If not recent, do NOT pretend delete succeeded.
        // Either implement re-auth (Apple reauth) or require sign-in again.
        guard hasAuthRecentlySignedIn(within: 300) else {
            isDeleting = false
            completion(false, "For security, please sign in again, then try deleting your account.")
            return
        }

        // 1) Delete Firestore user subtree first (avoids orphaning data)
        deleteFirestoreUserData { ok, message in
            guard ok else {
                self.isDeleting = false
                completion(false, message)
                return
            }

            // 2) Delete Auth user
            user.delete { error in
                self.isDeleting = false

                if let error {
                    // Most common: requires-recent-login (even after our check, can still happen)
                    completion(false, "Could not delete account: \(error.localizedDescription)")
                    return
                }

                completion(true, nil)
            }
        }
    }
}
