//
//  DeviceIdentity.swift
//  Mail Box Notifer
//
//  Created by user281046 on 2/2/26.
//

import UIKit

enum DeviceIdentity {
    private static let key = "stable_device_id"

    static func id() -> String {
        if let existing = UserDefaults.standard.string(forKey: key), !existing.isEmpty {
            return existing
        }
        let newID = UIDevice.current.identifierForVendor?.uuidString ?? UUID().uuidString
        UserDefaults.standard.set(newID, forKey: key)
        return newID
    }
}
